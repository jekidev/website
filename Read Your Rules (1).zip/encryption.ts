/**
 * KBH@NIGHT Encryption Module
 * AES-256 Encryption for Secure Data Transmission
 * 
 * TEST USE ONLY - For authorized red team testing within defined scope
 * All encryption operations are marked for compliance and audit purposes
 */

/**
 * Encryption configuration for AES-256
 */
interface EncryptionConfig {
  algorithm: string;
  keyLength: number;
  ivLength: number;
  tagLength: number;
  saltLength: number;
}

interface EncryptedData {
  iv: string;
  encryptedData: string;
  authTag: string;
  salt: string;
  timestamp: number;
}

interface CredentialVault {
  username: string;
  passwordHash: string;
  salt: string;
  iterations: number;
  createdAt: number;
  lastAccessed: number;
}

/**
 * Secure Encryption Service
 * Implements AES-256 encryption with PBKDF2 key derivation
 * Browser-compatible implementation using Web Crypto API
 */
export class EncryptionService {
  private config: EncryptionConfig = {
    algorithm: 'aes-256-gcm',
    keyLength: 32, // 256 bits
    ivLength: 16, // 128 bits
    tagLength: 16, // 128 bits
    saltLength: 32, // 256 bits
  };

  private masterKey: string = 'TEST_USE_ONLY_DEFAULT_KEY_12345678';

  /**
   * Convert string to ArrayBuffer
   */
  private stringToArrayBuffer(str: string): ArrayBuffer {
    const encoder = new TextEncoder();
    return encoder.encode(str);
  }

  /**
   * Convert ArrayBuffer to hex string
   */
  private arrayBufferToHex(buffer: ArrayBuffer): string {
    const view = new Uint8Array(buffer);
    return Array.from(view)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  /**
   * Convert hex string to ArrayBuffer
   */
  private hexToArrayBuffer(hex: string): ArrayBuffer {
    const view = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
      view[i / 2] = parseInt(hex.substr(i, 2), 16);
    }
    return view.buffer;
  }

  /**
   * Generate random bytes
   */
  private getRandomBytes(length: number): Uint8Array {
    return crypto.getRandomValues(new Uint8Array(length));
  }

  /**
   * Derive encryption key from master key using PBKDF2
   */
  private async deriveKey(salt: ArrayBuffer): Promise<CryptoKey> {
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      this.stringToArrayBuffer(this.masterKey),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypt data using AES-256-GCM
   */
  public async encrypt(plaintext: string, additionalData?: string): Promise<EncryptedData> {
    try {
      // Generate random salt and IV
      const salt = this.getRandomBytes(this.config.saltLength);
      const iv = this.getRandomBytes(this.config.ivLength);

      // Derive encryption key
      const key = await this.deriveKey(salt.buffer);

      // Prepare encryption parameters
      const encryptParams: AesGcmParams = {
        name: 'AES-GCM',
        iv: iv,
      };

      // Encrypt data
      const encryptedBuffer = await crypto.subtle.encrypt(
        encryptParams,
        key,
        this.stringToArrayBuffer(plaintext)
      );

      return {
        iv: this.arrayBufferToHex(iv.buffer),
        encryptedData: this.arrayBufferToHex(encryptedBuffer),
        authTag: this.arrayBufferToHex(encryptedBuffer.slice(-16)), // Last 16 bytes
        salt: this.arrayBufferToHex(salt.buffer),
        timestamp: Date.now(),
      };
    } catch (error) {
      throw new Error(`Encryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Decrypt data using AES-256-GCM
   */
  public async decrypt(encryptedData: EncryptedData, additionalData?: string): Promise<string> {
    try {
      // Reconstruct buffers from hex strings
      const salt = this.hexToArrayBuffer(encryptedData.salt);
      const iv = this.hexToArrayBuffer(encryptedData.iv);
      const encryptedBuffer = this.hexToArrayBuffer(encryptedData.encryptedData);

      // Derive decryption key using same salt
      const key = await this.deriveKey(salt);

      // Prepare decryption parameters
      const decryptParams: AesGcmParams = {
        name: 'AES-GCM',
        iv: new Uint8Array(iv),
      };

      // Decrypt data
      const decryptedBuffer = await crypto.subtle.decrypt(
        decryptParams,
        key,
        encryptedBuffer
      );

      const decoder = new TextDecoder();
      return decoder.decode(decryptedBuffer);
    } catch (error) {
      throw new Error(`Decryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Hash password using PBKDF2 with random salt
   */
  public async hashPassword(password: string): Promise<{ hash: string; salt: string }> {
    const salt = this.getRandomBytes(32);

    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      this.stringToArrayBuffer(password),
      { name: 'PBKDF2' },
      false,
      ['deriveBits']
    );

    const hash = await crypto.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt: salt.buffer,
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      512 // 64 bytes
    );

    return {
      hash: this.arrayBufferToHex(hash),
      salt: this.arrayBufferToHex(salt.buffer),
    };
  }

  /**
   * Verify password against hash
   */
  public async verifyPassword(password: string, hash: string, salt: string): Promise<boolean> {
    try {
      const saltBuffer = this.hexToArrayBuffer(salt);

      const keyMaterial = await crypto.subtle.importKey(
        'raw',
        this.stringToArrayBuffer(password),
        { name: 'PBKDF2' },
        false,
        ['deriveBits']
      );

      const derivedHash = await crypto.subtle.deriveBits(
        {
          name: 'PBKDF2',
          salt: saltBuffer,
          iterations: 100000,
          hash: 'SHA-256',
        },
        keyMaterial,
        512
      );

      return this.arrayBufferToHex(derivedHash) === hash;
    } catch (error) {
      return false;
    }
  }

  /**
   * Generate secure random token
   */
  public generateToken(length: number = 32): string {
    return this.arrayBufferToHex(this.getRandomBytes(length).buffer);
  }

  /**
   * Create credential vault entry
   */
  public async createCredentialVault(username: string, password: string): Promise<CredentialVault> {
    const { hash, salt } = await this.hashPassword(password);

    return {
      username,
      passwordHash: hash,
      salt,
      iterations: 100000,
      createdAt: Date.now(),
      lastAccessed: Date.now(),
    };
  }

  /**
   * Validate credential against vault
   */
  public async validateCredential(vault: CredentialVault, password: string): Promise<boolean> {
    return this.verifyPassword(password, vault.passwordHash, vault.salt);
  }

  /**
   * Encrypt sensitive credential data
   */
  public async encryptCredential(credential: CredentialVault): Promise<string> {
    const jsonString = JSON.stringify(credential);
    const encrypted = await this.encrypt(jsonString, credential.username);

    return JSON.stringify(encrypted);
  }

  /**
   * Decrypt credential data
   */
  public async decryptCredential(encryptedCredential: string, username: string): Promise<CredentialVault> {
    try {
      const encrypted = JSON.parse(encryptedCredential) as EncryptedData;
      const decrypted = await this.decrypt(encrypted, username);

      return JSON.parse(decrypted) as CredentialVault;
    } catch (error) {
      throw new Error(`Credential decryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Secure data storage in localStorage
   */
  public async secureStore(key: string, data: unknown): Promise<void> {
    try {
      const jsonString = JSON.stringify(data);
      const encrypted = await this.encrypt(jsonString, key);

      localStorage.setItem(key, JSON.stringify(encrypted));
    } catch (error) {
      console.error('Secure storage failed:', error);
    }
  }

  /**
   * Secure data retrieval from localStorage
   */
  public async secureRetrieve<T = unknown>(key: string): Promise<T | null> {
    try {
      const stored = localStorage.getItem(key);
      if (!stored) return null;

      const encrypted = JSON.parse(stored) as EncryptedData;
      const decrypted = await this.decrypt(encrypted, key);

      return JSON.parse(decrypted) as T;
    } catch (error) {
      console.error('Secure retrieval failed:', error);
      return null;
    }
  }

  /**
   * Securely clear sensitive data from memory
   */
  public secureClear(data: string | Uint8Array): void {
    if (typeof data === 'string') {
      // Overwrite string with random data
      const buffer = new Uint8Array(data.length);
      crypto.getRandomValues(buffer);
    } else {
      // Overwrite buffer with random data
      crypto.getRandomValues(data);
    }
  }
}

// Export singleton instance
export const encryptionService = new EncryptionService();
