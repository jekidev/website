#!/usr/bin/env python3

"""
Signal Auto-Poster & Installer
TEST USE ONLY - For authorized red team testing within defined scope

Automatic Signal group message automation with:
- Automatic Java and signal-cli installation
- QR code generation for device linking
- Batch message posting to Signal groups
- Automatic dependency management
"""

import os
import sys
import subprocess
import threading
import requests
import zipfile
import tarfile
import platform
import json
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import messagebox, scrolledtext
    from PIL import ImageTk, Image
    import qrcode
except ImportError:
    print("Installing required Python packages...")
    subprocess.run([sys.executable, "-m", "pip", "install", "qrcode[pil]", "pillow", "requests"], check=True)
    import tkinter as tk
    from tkinter import messagebox, scrolledtext
    from PIL import ImageTk, Image
    import qrcode


class SignalBotGUI:
    """Signal Auto-Poster GUI with automatic setup."""

    def __init__(self, root):
        self.root = root
        self.root.title("Signal Auto-Poster & Installer - TEST USE ONLY")
        self.root.geometry("700x900")
        self.root.configure(bg="#1a1a1a")
        
        # Paths and settings
        self.base_dir = os.getcwd()
        self.signal_cli_path = os.path.join(self.base_dir, "signal-cli", "bin", "signal-cli")
        if platform.system() == "Windows":
            self.signal_cli_path += ".bat"
        
        self.setup_ui()

    def setup_ui(self):
        """Setup the GUI interface."""
        # Header
        header = tk.Label(
            self.root,
            text="Signal Auto-Poster",
            font=("Arial", 18, "bold"),
            bg="#1a1a1a",
            fg="#00ff00"
        )
        header.pack(pady=10)

        # Status box
        self.status_box = scrolledtext.ScrolledText(
            self.root,
            height=10,
            width=80,
            font=("Courier", 9),
            bg="#000000",
            fg="#00ff00"
        )
        self.status_box.pack(pady=5, padx=10)
        self.log("TEST USE ONLY - Authorized Testing Framework")
        self.log("Click '1. Setup System' to begin...")

        # Button frame
        btn_frame = tk.Frame(self.root, bg="#1a1a1a")
        btn_frame.pack(pady=10)

        tk.Button(
            btn_frame,
            text="1. Setup System",
            command=self.run_setup,
            bg="#3498db",
            fg="white",
            font=("Arial", 10, "bold"),
            width=20
        ).grid(row=0, column=0, padx=5, pady=5)

        tk.Button(
            btn_frame,
            text="2. Link Device (QR)",
            command=self.link_account,
            bg="#2ecc71",
            fg="white",
            font=("Arial", 10, "bold"),
            width=20
        ).grid(row=0, column=1, padx=5, pady=5)

        # Recipients
        tk.Label(self.root, text="Recipients (Group IDs, comma-separated):", bg="#1a1a1a", fg="#ffffff").pack()
        self.groups_entry = tk.Entry(self.root, width=80, bg="#2a2a2a", fg="#ffffff")
        self.groups_entry.pack(pady=5)

        # Message
        tk.Label(self.root, text="Message:", bg="#1a1a1a", fg="#ffffff").pack()
        self.message_entry = tk.Text(self.root, height=5, width=80, bg="#2a2a2a", fg="#ffffff")
        self.message_entry.pack(pady=5)

        # Send button
        tk.Button(
            self.root,
            text="3. SEND MESSAGES",
            command=self.start_posting,
            bg="#e74c3c",
            fg="white",
            font=("Arial", 12, "bold"),
            width=80
        ).pack(pady=20)

        # QR display
        self.qr_label = tk.Label(self.root, bg="#1a1a1a")
        self.qr_label.pack(pady=10)

    def log(self, text):
        """Add text to status box."""
        self.status_box.insert(tk.END, f"> {text}\n")
        self.status_box.see(tk.END)
        self.root.update()

    def run_setup(self):
        """Run setup in background thread."""
        threading.Thread(target=self._setup_thread, daemon=True).start()

    def _setup_thread(self):
        """Setup thread - check Java and download signal-cli."""
        try:
            # Check Java
            self.log("Checking for Java...")
            try:
                subprocess.run(["java", "-version"], check=True, capture_output=True, timeout=5)
                self.log("✓ Java found!")
            except:
                self.log("✗ Java not found. Installing...")
                self.log("Please install Java from: https://adoptium.net/")
                messagebox.showerror(
                    "Java Required",
                    "Please install OpenJDK 17+ from https://adoptium.net/\n"
                    "Then restart this application."
                )
                return

            # Download signal-cli
            if not os.path.exists(self.signal_cli_path):
                self.log("Downloading signal-cli...")
                url = "https://github.com/AsamK/signal-cli/releases/download/v0.13.1/signal-cli-0.13.1.tar.gz"
                
                try:
                    response = requests.get(url, stream=True, timeout=30)
                    response.raise_for_status()
                    
                    with open("signal-cli.tar.gz", "wb") as f:
                        total = int(response.headers.get('content-length', 0))
                        downloaded = 0
                        for chunk in response.iter_content(chunk_size=8192):
                            downloaded += len(chunk)
                            f.write(chunk)
                            progress = int((downloaded / total) * 100) if total else 0
                            self.log(f"Downloading... {progress}%")
                    
                    self.log("Extracting signal-cli...")
                    with tarfile.open("signal-cli.tar.gz", "r:gz") as tar:
                        tar.extractall(path=self.base_dir)
                    
                    # Rename folder
                    old_path = os.path.join(self.base_dir, "signal-cli-0.13.1")
                    new_path = os.path.join(self.base_dir, "signal-cli")
                    if os.path.exists(old_path):
                        os.rename(old_path, new_path)
                    
                    os.remove("signal-cli.tar.gz")
                    self.log("✓ signal-cli installed!")
                except Exception as e:
                    self.log(f"✗ Download failed: {str(e)}")
                    return
            else:
                self.log("✓ signal-cli already installed!")

            self.log("✓ System setup complete!")
            messagebox.showinfo("Success", "System setup complete!\n\nNext: Click '2. Link Device (QR)'")

        except Exception as e:
            self.log(f"✗ Setup error: {str(e)}")
            messagebox.showerror("Setup Error", f"Setup failed: {str(e)}")

    def link_account(self):
        """Link Signal account via QR code."""
        threading.Thread(target=self._link_thread, daemon=True).start()

    def _link_thread(self):
        """Link thread - get QR code from signal-cli."""
        try:
            self.log("Getting linking QR code...")
            process = subprocess.Popen(
                [self.signal_cli_path, "link"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30
            )
            
            for line in process.stdout:
                if "tsdevice:?" in line:
                    uri = line.strip()
                    self.show_qr(uri)
                    self.log("✓ QR code generated! Scan it in Signal app.")
                    self.log("Go to: Settings → Linked Devices → Link New Device")
                    break
            
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            self.log("✗ Linking timeout")
        except Exception as e:
            self.log(f"✗ Linking error: {str(e)}")

    def show_qr(self, uri):
        """Display QR code."""
        try:
            qr = qrcode.make(uri)
            qr = qr.resize((250, 250))
            self.img = ImageTk.PhotoImage(qr)
            self.qr_label.config(image=self.img)
        except Exception as e:
            self.log(f"✗ QR generation error: {str(e)}")

    def start_posting(self):
        """Start posting messages."""
        msg = self.message_entry.get("1.0", tk.END).strip()
        groups_text = self.groups_entry.get().strip()

        if not msg or not groups_text:
            messagebox.showwarning("Input Error", "Please enter message and recipients")
            return

        groups = [g.strip() for g in groups_text.split(",") if g.strip()]
        threading.Thread(target=self._post_thread, args=(groups, msg), daemon=True).start()

    def _post_thread(self, groups, msg):
        """Posting thread - send messages to groups."""
        for group in groups:
            self.log(f"Sending to {group}...")
            try:
                subprocess.run(
                    [self.signal_cli_path, "send", "-g", group, "-m", msg],
                    check=True,
                    timeout=10,
                    capture_output=True
                )
                self.log(f"✓ Sent to {group}")
            except Exception as e:
                self.log(f"✗ Failed to send to {group}: {str(e)}")
        
        self.log("--- Posting complete ---")
        messagebox.showinfo("Complete", "Message posting finished!")


def main():
    """Main entry point."""
    print("\n" + "="*60)
    print("Signal Auto-Poster")
    print("TEST USE ONLY - Authorized Testing Framework")
    print("="*60 + "\n")

    root = tk.Tk()
    app = SignalBotGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
