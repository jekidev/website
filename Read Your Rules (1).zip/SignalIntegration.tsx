import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Radio, Send, QrCode, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

/**
 * KBH@NIGHT Signal Integration Module
 * Design Philosophy: Secure Communication Interface
 * - QR code generation for device linking
 * - Group management and message distribution
 * - Encrypted channel configuration
 * - Delivery status tracking
 */

interface SignalGroup {
  id: string;
  name: string;
  members: number;
  lastMessage: string;
  status: 'active' | 'dormant' | 'archived';
}

interface MessageJob {
  id: string;
  timestamp: string;
  message: string;
  recipients: number;
  status: 'pending' | 'sent' | 'failed' | 'partial';
  deliveryRate: number;
}

export default function SignalIntegration() {
  const [authenticated, setAuthenticated] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);
  const [qrCodeData, setQrCodeData] = useState('');
  
  const [groups, setGroups] = useState<SignalGroup[]>([
    { id: '1', name: 'SECURE_BROADCAST', members: 12, lastMessage: '2 mins ago', status: 'active' },
    { id: '2', name: 'OPERATIONAL_CELL_A', members: 8, lastMessage: '15 mins ago', status: 'active' },
    { id: '3', name: 'FINANCIAL_TEAM', members: 5, lastMessage: '1 hour ago', status: 'active' },
    { id: '4', name: 'ARCHIVE_2024', members: 23, lastMessage: '3 days ago', status: 'archived' },
  ]);

  const [messageJobs, setMessageJobs] = useState<MessageJob[]>([
    { id: '1', timestamp: '2025-01-17 20:45', message: 'Operational update required', recipients: 25, status: 'sent', deliveryRate: 100 },
    { id: '2', timestamp: '2025-01-17 19:30', message: 'Security protocol refresh', recipients: 18, status: 'sent', deliveryRate: 94 },
    { id: '3', timestamp: '2025-01-17 18:15', message: 'Pending verification', recipients: 12, status: 'partial', deliveryRate: 83 },
  ]);

  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [messageText, setMessageText] = useState('');
  const [showSendDialog, setShowSendDialog] = useState(false);

  const handleLinkDevice = () => {
    // TEST USE ONLY - Generate mock QR code URI
    const mockUri = `tsdevice:/?uuid=kbh_${Math.random().toString(36).substr(2, 9)}&key=${Math.random().toString(36).substr(2, 20)}`;
    setQrCodeData(mockUri);
    setShowQRCode(true);
  };

  const handleSelectGroup = (groupId: string) => {
    setSelectedGroups(prev =>
      prev.includes(groupId)
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || selectedGroups.length === 0) {
      alert('Please enter a message and select at least one group');
      return;
    }

    // Create new message job
    const newJob: MessageJob = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      message: messageText,
      recipients: selectedGroups.length * 8, // Mock calculation
      status: 'pending',
      deliveryRate: 0,
    };

    setMessageJobs([newJob, ...messageJobs]);
    setMessageText('');
    setSelectedGroups([]);
    setShowSendDialog(false);

    // Simulate delivery
    setTimeout(() => {
      setMessageJobs(prev =>
        prev.map(job =>
          job.id === newJob.id
            ? { ...job, status: 'sent', deliveryRate: 98 }
            : job
        )
      );
    }, 2000);
  };

  if (!authenticated) {
    return (
      <div className="relative w-full min-h-screen overflow-hidden bg-black flex flex-col items-center justify-center px-4">
        <video
          autoPlay
          muted
          loop
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'brightness(0.4) contrast(1.1)' }}
        >
          <source src="/grok-video-785eb3b5-d895-41a9-8f34-b0ee2c4fd318.mp4" type="video/mp4" />
        </video>

        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/80" />

        <div className="relative z-10 text-center max-w-md">
          <Radio className="w-16 h-16 text-cyan-400 mx-auto mb-6" />
          <h1 className="text-3xl font-light tracking-widest text-white mb-4" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
            SIGNAL LINK
          </h1>
          <p className="text-gray-300 text-sm mb-8">
            Scan the QR code below with your Signal app to link this device as a secondary endpoint.
          </p>
          <Button
            onClick={handleLinkDevice}
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-semibold py-3 rounded-lg mb-4 flex items-center justify-center gap-2"
          >
            <QrCode className="w-5 h-5" />
            GENERATE QR CODE
          </Button>
          <Button
            onClick={() => setAuthenticated(true)}
            className="w-full bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold py-3 rounded-lg"
          >
            SKIP TO DASHBOARD
          </Button>
        </div>

        {/* QR Code Display Dialog */}
        <Dialog open={showQRCode} onOpenChange={setShowQRCode}>
          <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-sm shadow-2xl">
            <DialogHeader>
              <DialogTitle className="text-lg font-light tracking-widest text-white flex items-center gap-3">
                <QrCode className="w-4 h-4 text-cyan-400" />
                DEVICE LINKING QR CODE
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="text-xs font-mono text-gray-600 mb-2">TEST USE ONLY</div>
                  <div className="text-sm font-mono text-gray-800 break-all">{qrCodeData}</div>
                </div>
              </div>
              <div className="bg-amber-500/10 border border-amber-500/30 rounded p-3">
                <div className="flex gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-300">
                    Scan this code with Signal app under "Linked Devices" settings. Code expires in 30 minutes.
                  </p>
                </div>
              </div>
              <Button
                onClick={() => setAuthenticated(true)}
                className="w-full bg-white text-black hover:bg-gray-200 font-semibold text-sm h-10"
              >
                PROCEED TO DASHBOARD
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-black">
      <video
        autoPlay
        muted
        loop
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'brightness(0.3) contrast(1.2)' }}
      >
        <source src="/grok-video-65aa1047-1315-4729-b3d4-efb51ddbc143.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/80" />

      <div className="relative z-10 min-h-screen px-4 sm:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl sm:text-5xl font-light tracking-tight text-white mb-2" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
              SIGNAL OPERATIONS
            </h1>
            <div className="h-px w-40 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Groups Panel */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
                <h2 className="text-lg font-light tracking-widest text-white mb-4 flex items-center gap-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                  <Radio className="w-4 h-4 text-cyan-400" />
                  GROUPS
                </h2>
                <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar">
                  {groups.map(group => (
                    <div
                      key={group.id}
                      onClick={() => handleSelectGroup(group.id)}
                      className={`p-3 rounded cursor-pointer transition-all border ${
                        selectedGroups.includes(group.id)
                          ? 'bg-cyan-500/20 border-cyan-400/50'
                          : 'bg-black/30 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="font-mono text-sm text-white font-semibold">{group.name}</div>
                          <div className="text-xs text-gray-400 mt-1">{group.members} members</div>
                        </div>
                        <div className={`w-4 h-4 rounded border-2 ${
                          selectedGroups.includes(group.id)
                            ? 'bg-cyan-400 border-cyan-400'
                            : 'border-white/30'
                        }`} />
                      </div>
                      <div className={`text-xs mt-2 px-2 py-1 rounded inline-block ${
                        group.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' :
                        group.status === 'dormant' ? 'bg-gray-500/20 text-gray-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {group.status.toUpperCase()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Message Composer */}
            <div className="lg:col-span-2">
              <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm mb-8">
                <h2 className="text-lg font-light tracking-widest text-white mb-4 flex items-center gap-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                  <Send className="w-4 h-4 text-cyan-400" />
                  COMPOSE MESSAGE
                </h2>
                <textarea
                  placeholder="Enter your message here..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  className="w-full bg-black/30 border border-white/10 rounded p-4 text-gray-300 font-mono text-sm focus:outline-none focus:border-white/30 focus:bg-black/50 resize-none transition-all duration-300 placeholder:text-gray-600 mb-4"
                  rows={6}
                />
                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowSendDialog(true)}
                    disabled={selectedGroups.length === 0 || !messageText.trim()}
                    className="flex-1 bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-600 text-white font-semibold py-3 rounded flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    SEND TO {selectedGroups.length} GROUP{selectedGroups.length !== 1 ? 'S' : ''}
                  </Button>
                </div>
              </div>

              {/* Message History */}
              <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
                <h2 className="text-lg font-light tracking-widest text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                  MESSAGE HISTORY
                </h2>
                <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
                  {messageJobs.map(job => (
                    <div key={job.id} className="bg-black/30 border border-white/10 rounded p-4 hover:border-white/20 transition-all">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          {job.status === 'sent' && <CheckCircle className="w-4 h-4 text-emerald-400" />}
                          {job.status === 'partial' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                          {job.status === 'failed' && <XCircle className="w-4 h-4 text-red-400" />}
                          {job.status === 'pending' && <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse" />}
                          <span className="text-xs font-mono text-gray-400">{job.timestamp}</span>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded font-mono ${
                          job.status === 'sent' ? 'bg-emerald-500/20 text-emerald-400' :
                          job.status === 'partial' ? 'bg-amber-500/20 text-amber-400' :
                          job.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                          'bg-cyan-500/20 text-cyan-400'
                        }`}>
                          {job.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-300 mb-2">{job.message}</p>
                      <div className="flex justify-between items-center text-xs text-gray-400">
                        <span>{job.recipients} recipients</span>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-black/50 rounded h-1.5 overflow-hidden">
                            <div
                              className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-full transition-all"
                              style={{ width: `${job.deliveryRate}%` }}
                            />
                          </div>
                          <span className="w-8 text-right">{job.deliveryRate}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Send Confirmation Dialog */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-md shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-light tracking-widest text-white">
              CONFIRM BROADCAST
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-white/5 border border-white/10 rounded p-4">
              <div className="text-xs font-mono text-gray-400 mb-2">MESSAGE PREVIEW</div>
              <p className="text-sm text-gray-300">{messageText}</p>
            </div>
            <div className="bg-white/5 border border-white/10 rounded p-4">
              <div className="text-xs font-mono text-gray-400 mb-2">RECIPIENTS</div>
              <div className="text-sm text-gray-300 space-y-1">
                {selectedGroups.map(id => {
                  const group = groups.find(g => g.id === id);
                  return group ? <div key={id}>• {group.name} ({group.members} members)</div> : null;
                })}
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => setShowSendDialog(false)}
                className="flex-1 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold py-2 rounded"
              >
                CANCEL
              </Button>
              <Button
                onClick={handleSendMessage}
                className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold py-2 rounded"
              >
                SEND
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(34, 211, 238, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(34, 211, 238, 0.5);
        }
      `}</style>
    </div>
  );
}
