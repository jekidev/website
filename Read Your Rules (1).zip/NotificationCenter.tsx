import { useState, useEffect } from 'react';
import { X, AlertCircle, MessageSquare, Bell, CheckCircle, AlertTriangle } from 'lucide-react';

interface Notification {
  type: 'message' | 'alert' | 'status' | 'forum' | 'admin' | 'system';
  title: string;
  content: string;
  timestamp: Date;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  id?: string;
}

interface NotificationCenterProps {
  notifications: Notification[];
  onDismiss: (id: string) => void;
  maxVisible?: number;
}

export function NotificationCenter({
  notifications,
  onDismiss,
  maxVisible = 5,
}: NotificationCenterProps) {
  const [visible, setVisible] = useState<Notification[]>([]);

  useEffect(() => {
    setVisible(notifications.slice(0, maxVisible));
  }, [notifications, maxVisible]);

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'alert':
        return <AlertTriangle className="w-5 h-5" />;
      case 'message':
        return <MessageSquare className="w-5 h-5" />;
      case 'forum':
        return <Bell className="w-5 h-5" />;
      case 'status':
        return <CheckCircle className="w-5 h-5" />;
      default:
        return <AlertCircle className="w-5 h-5" />;
    }
  };

  const getColor = (priority?: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-red-500/20 border-red-500/50 text-red-400';
      case 'high':
        return 'bg-orange-500/20 border-orange-500/50 text-orange-400';
      case 'medium':
        return 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400';
      default:
        return 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400';
    }
  };

  return (
    <div className="fixed bottom-4 right-4 space-y-3 z-50 max-w-md">
      {visible.map((notification, idx) => (
        <div
          key={`${notification.timestamp}-${idx}`}
          className={`p-4 rounded-lg border backdrop-blur-xl glass-effect-dark ${getColor(
            notification.priority
          )} animate-in fade-in slide-in-from-right-4 duration-300`}
        >
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 mt-0.5">{getIcon(notification.type)}</div>
            <div className="flex-1 min-w-0">
              <h3 className="font-mono text-sm font-semibold truncate">
                {notification.title}
              </h3>
              <p className="text-xs mt-1 opacity-90 line-clamp-2">
                {notification.content}
              </p>
              <p className="text-xs opacity-60 mt-2 font-mono">
                {new Date(notification.timestamp).toLocaleTimeString()}
              </p>
            </div>
            <button
              onClick={() => onDismiss(`${notification.timestamp}-${idx}`)}
              className="flex-shrink-0 hover:opacity-75 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

export function NotificationBadge({ count }: { count: number }) {
  if (count === 0) return null;

  return (
    <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2">
      <div className="flex items-center justify-center w-6 h-6 rounded-full bg-red-500 text-white text-xs font-bold">
        {count > 99 ? '99+' : count}
      </div>
    </div>
  );
}

export function NotificationPanel({ notifications }: { notifications: Notification[] }) {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  return (
    <div className="space-y-2 max-h-96 overflow-y-auto">
      {notifications.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No notifications</p>
        </div>
      ) : (
        notifications.map((notification, idx) => (
          <div
            key={idx}
            className="p-3 rounded-lg border border-cyan-500/20 bg-black/50 hover:bg-black/70 cursor-pointer transition-all"
            onClick={() => setExpandedId(expandedId === idx ? null : idx)}
          >
            <div className="flex items-start gap-2">
              <div className="flex-shrink-0 mt-0.5 text-cyan-400">
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-mono text-sm font-semibold text-cyan-400 truncate">
                  {notification.title}
                </h4>
                {expandedId === idx && (
                  <p className="text-xs text-gray-300 mt-2 whitespace-pre-wrap">
                    {notification.content}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1 font-mono">
                  {new Date(notification.timestamp).toLocaleString()}
                </p>
              </div>
              {notification.priority === 'critical' && (
                <div className="flex-shrink-0 w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function getIcon(type: Notification['type']) {
  switch (type) {
    case 'alert':
      return <AlertTriangle className="w-4 h-4" />;
    case 'message':
      return <MessageSquare className="w-4 h-4" />;
    case 'forum':
      return <Bell className="w-4 h-4" />;
    case 'status':
      return <CheckCircle className="w-4 h-4" />;
    default:
      return <AlertCircle className="w-4 h-4" />;
  }
}
