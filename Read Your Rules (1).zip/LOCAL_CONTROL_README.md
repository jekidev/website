# KBH@NIGHT Local Control & Automation

**TEST USE ONLY** - For authorized red team testing within defined scope only.

## Overview

This document describes the local control GUI and GitHub Actions deployment automation for the KBH@NIGHT framework.

## Local Control GUI (PyQt6)

### Installation

```bash
# Install PyQt6
pip install PyQt6

# Make the script executable
chmod +x local-control-gui.py
```

### Usage

```bash
# Run the GUI
python3 local-control-gui.py
```

### Features

The local control GUI provides a desktop interface for managing:

- **Member Management** – Create and manage collective members with role assignment
- **Site Cloning** – Configure and manage cloned sites with rotation capabilities
- **Malware Distribution** – Add and manage malware distribution links with access controls
- **Phishing Redirection** – Configure phishing redirect targets (via web dashboard)

### GUI Tabs

#### Members Tab
- Add new members with username and role selection (member/operator/admin)
- View active members list
- Manage member status and access levels

#### Site Clones Tab
- Create new site clones with cloned and original URLs
- View all configured clones
- Monitor active clone status
- Manage rotation schedules

#### Malware Distribution Tab
- Add malware distribution links with optional weekend-only access
- Track download counts
- Manage access requirements by role
- Monitor distribution status

### Connection Requirements

- Backend must be running on `http://localhost:3000`
- API endpoints accessible at `/api/trpc/operational.*`
- Admin credentials required for sensitive operations

## GitHub Actions Deployment Automation

### Default Schedule

The default GitHub Actions workflow deploys the application:
- **Days**: Monday-Friday (1-5)
- **Time**: 02:00 UTC
- **Cron**: `0 2 * * 1-5`

### Configuration Script

Use the deployment configuration script to modify deployment days and times:

```bash
# Modify deployment schedule
node scripts/configure-deployment-days.mjs --days 1-5 --time 14:30

# Deploy on weekends only
node scripts/configure-deployment-days.mjs --days 0,6 --time 10:00

# Deploy daily
node scripts/configure-deployment-days.mjs --days 0-6 --time 02:00

# Show help
node scripts/configure-deployment-days.mjs --help
```

### Cron Expression Format

```
minute hour day-of-month month day-of-week
  0     2    *            *     1-5
```

**Day-of-week values:**
- 0 = Sunday
- 1 = Monday
- 2 = Tuesday
- 3 = Wednesday
- 4 = Thursday
- 5 = Friday
- 6 = Saturday

### Examples

```bash
# Monday-Friday at 02:00 UTC
node scripts/configure-deployment-days.mjs --days 1-5 --time 02:00

# Weekends at 10:00 UTC
node scripts/configure-deployment-days.mjs --days 0,6 --time 10:00

# Every day at 15:30 UTC
node scripts/configure-deployment-days.mjs --days 0-6 --time 15:30

# Specific days: Monday, Wednesday, Friday at 09:00 UTC
node scripts/configure-deployment-days.mjs --days 1,3,5 --time 09:00
```

### Manual Deployment

Trigger deployment manually via GitHub Actions UI or CLI:

```bash
gh workflow run daily-deploy.yml
```

### Deployment Workflow Steps

1. **Checkout Code** – Clone repository at current commit
2. **Setup Node.js** – Install Node.js 22 with pnpm
3. **Install Dependencies** – Install project dependencies
4. **Build Project** – Compile TypeScript and bundle assets
5. **Run Tests** – Execute test suite (non-blocking)
6. **Deploy** – Deploy to Manus platform
7. **Create Deployment Record** – Log deployment metadata
8. **Upload Artifacts** – Store deployment logs
9. **Notify** – Send deployment completion notification

### Deployment Logs

Deployment logs are stored as GitHub Actions artifacts and retained for 30 days:
- Accessible from Actions tab in repository
- Contains deployment timestamp, commit hash, and branch

### Environment Variables

The workflow uses the following environment variables:
- `DEPLOYMENT_ENV`: Set to `production`
- `TEST_MODE`: Set to `true` (TEST USE ONLY)

### Monitoring Deployments

View deployment history:

```bash
# List recent workflow runs
gh run list --workflow=daily-deploy.yml

# View specific run details
gh run view <RUN_ID>

# Download deployment logs
gh run download <RUN_ID> --dir deployment-logs
```

## Security Considerations

- **TEST USE ONLY** – All features are labeled for authorized testing only
- **Scope Limitation** – Deployments limited to in-scope targets (cfg-staging.dk, internal-test.cfg.dk)
- **Access Control** – Admin credentials required for sensitive operations
- **Audit Logging** – All operations logged for compliance and review
- **Encryption** – Sensitive data encrypted in transit and at rest

## Troubleshooting

### GUI Connection Issues

```bash
# Verify backend is running
curl http://localhost:3000/api/trpc/auth.me

# Check API endpoint
curl http://localhost:3000/api/trpc/operational.getAllMembers
```

### Deployment Issues

```bash
# Check workflow status
gh workflow view daily-deploy.yml

# View recent failures
gh run list --workflow=daily-deploy.yml --status failed

# View workflow logs
gh run view <RUN_ID> --log
```

### Configuration Script Issues

```bash
# Verify workflow file syntax
cat .github/workflows/daily-deploy.yml

# Test cron expression
# Use crontab.guru to validate cron expressions
```

## Compliance & Documentation

All deployments are automatically documented:
- Deployment timestamp (UTC)
- Commit hash
- Branch name
- Deployment status
- Test mode indicator

This ensures full traceability for post-engagement review and compliance reporting.

---

**TEST USE ONLY** - Authorized Testing Framework  
For use only within the defined Rules of Engagement scope.
