import { useEffect, useState } from 'react';

export function FuturisticHUDElements() {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Animated corner brackets */}
      <div className="fixed top-4 left-4 z-40 pointer-events-none">
        <div className="relative w-12 h-12">
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400 opacity-60 animate-pulse" />
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400 opacity-60 animate-pulse" />
        </div>
      </div>

      <div className="fixed top-4 right-4 z-40 pointer-events-none">
        <div className="relative w-12 h-12">
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400 opacity-60 animate-pulse" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400 opacity-60 animate-pulse" />
        </div>
      </div>

      <div className="fixed bottom-4 left-4 z-40 pointer-events-none">
        <div className="relative w-12 h-12">
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-purple-400 opacity-60 animate-pulse" />
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-purple-400 opacity-60 animate-pulse" />
        </div>
      </div>

      <div className="fixed bottom-4 right-4 z-40 pointer-events-none">
        <div className="relative w-12 h-12">
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-purple-400 opacity-60 animate-pulse" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-purple-400 opacity-60 animate-pulse" />
        </div>
      </div>

      {/* Top HUD bar */}
      <div className="fixed top-0 left-1/2 transform -translate-x-1/2 z-40 pointer-events-none w-full max-w-4xl">
        <div className="relative h-12 bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent border-b border-cyan-400/30 backdrop-blur-sm">
          <div className="absolute inset-0 flex items-center justify-between px-8">
            <div className="text-xs font-mono text-cyan-400 opacity-60 animate-pulse">
              [SYSTEM ONLINE]
            </div>
            <div className="text-xs font-mono text-cyan-400 opacity-60">
              {time}
            </div>
            <div className="text-xs font-mono text-cyan-400 opacity-60 animate-pulse">
              [SECURE CONNECTION]
            </div>
          </div>
          {/* Animated scan line */}
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" />
        </div>
      </div>

      {/* Bottom HUD bar */}
      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 z-40 pointer-events-none w-full max-w-4xl">
        <div className="relative h-12 bg-gradient-to-r from-transparent via-purple-400/10 to-transparent border-t border-purple-400/30 backdrop-blur-sm">
          <div className="absolute inset-0 flex items-center justify-between px-8">
            <div className="text-xs font-mono text-purple-400 opacity-60">
              [ENCRYPTED]
            </div>
            <div className="text-xs font-mono text-purple-400 opacity-60 animate-pulse">
              ▌ MONITORING ACTIVE
            </div>
            <div className="text-xs font-mono text-purple-400 opacity-60">
              [AUTHORIZED]
            </div>
          </div>
          {/* Animated scan line */}
          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-purple-400 to-transparent animate-pulse" />
        </div>
      </div>

      {/* Floating data streams */}
      <div className="fixed left-0 top-1/4 z-10 pointer-events-none opacity-30">
        <div className="space-y-4 font-mono text-xs text-cyan-400/40">
          <div className="animate-pulse">0x7F45</div>
          <div className="animate-pulse delay-100">0x8A2C</div>
          <div className="animate-pulse delay-200">0x9B3D</div>
          <div className="animate-pulse delay-300">0xC4E1</div>
        </div>
      </div>

      <div className="fixed right-0 top-1/3 z-10 pointer-events-none opacity-30">
        <div className="space-y-4 font-mono text-xs text-purple-400/40 text-right">
          <div className="animate-pulse">SIGNAL_OK</div>
          <div className="animate-pulse delay-100">LINK_STABLE</div>
          <div className="animate-pulse delay-200">STATUS_GREEN</div>
          <div className="animate-pulse delay-300">READY</div>
        </div>
      </div>

      {/* Animated grid background */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(0deg,transparent_24%,rgba(0,255,255,0.05)_25%,rgba(0,255,255,0.05)_26%,transparent_27%,transparent_74%,rgba(0,255,255,0.05)_75%,rgba(0,255,255,0.05)_76%,transparent_77%,transparent),linear-gradient(90deg,transparent_24%,rgba(0,255,255,0.05)_25%,rgba(0,255,255,0.05)_26%,transparent_27%,transparent_74%,rgba(0,255,255,0.05)_75%,rgba(0,255,255,0.05)_76%,transparent_77%,transparent)] bg-[length:50px_50px] opacity-10" />
      </div>

      {/* Floating orbs */}
      <div className="fixed top-1/2 left-1/4 z-10 pointer-events-none">
        <div className="w-32 h-32 bg-cyan-400 rounded-full opacity-5 blur-3xl animate-pulse" />
      </div>

      <div className="fixed bottom-1/4 right-1/4 z-10 pointer-events-none">
        <div className="w-40 h-40 bg-purple-400 rounded-full opacity-5 blur-3xl animate-pulse" />
      </div>

      {/* Vertical scan lines */}
      <div className="fixed inset-0 z-20 pointer-events-none opacity-5">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(255,255,255,0.03)_2px,rgba(255,255,255,0.03)_4px)] animate-pulse" />
      </div>

      {/* Animated border glow */}
      <div className="fixed inset-0 z-30 pointer-events-none">
        <div className="absolute inset-0 border border-cyan-400/20 opacity-0 animate-[pulse_3s_ease-in-out_infinite]" />
      </div>
    </>
  );
}

export function HUDPanel({
  title,
  children,
  className = '',
}: {
  title: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`relative bg-black/40 border border-cyan-400/30 rounded-lg backdrop-blur-xl overflow-hidden ${className}`}>
      {/* Panel glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 to-transparent pointer-events-none" />

      {/* Panel header */}
      <div className="relative border-b border-cyan-400/20 px-4 py-3 bg-gradient-to-r from-cyan-400/10 to-transparent">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
          <h3 className="font-mono text-sm font-semibold text-cyan-400 tracking-widest">
            {title}
          </h3>
        </div>
      </div>

      {/* Panel content */}
      <div className="relative p-4">
        {children}
      </div>

      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400/50" />
      <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400/50" />
      <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400/50" />
      <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400/50" />
    </div>
  );
}
