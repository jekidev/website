import { useEffect, useState, useCallback, useRef } from 'react';
import { io, Socket } from 'socket.io-client';

interface NotificationPayload {
  type: 'message' | 'alert' | 'status' | 'forum' | 'admin' | 'system';
  title: string;
  content: string;
  timestamp: Date;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  targetRole?: 'admin' | 'runner' | 'member' | 'all';
  data?: Record<string, unknown>;
}

interface UseWebSocketOptions {
  role: 'admin' | 'runner' | 'member';
  token?: string;
  onNotification?: (notification: NotificationPayload) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
}

export function useWebSocket({
  role,
  token,
  onNotification,
  onConnect,
  onDisconnect,
}: UseWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [notifications, setNotifications] = useState<NotificationPayload[]>([]);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // Initialize socket connection
    const socket = io(window.location.origin, {
      auth: {
        token: token || 'default',
        role,
      },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    socketRef.current = socket;

    // Connection handlers
    socket.on('connect', () => {
      console.log('[WebSocket] Connected');
      setIsConnected(true);
      onConnect?.();
    });

    socket.on('disconnect', () => {
      console.log('[WebSocket] Disconnected');
      setIsConnected(false);
      onDisconnect?.();
    });

    // Notification handler
    socket.on('notification', (notification: NotificationPayload) => {
      console.log('[Notification]', notification);
      setNotifications((prev) => [notification, ...prev].slice(0, 100)); // Keep last 100
      onNotification?.(notification);
    });

    // Connection confirmation
    socket.on('connected', (data) => {
      console.log('[WebSocket] Connection confirmed:', data);
    });

    // Error handler
    socket.on('error', (error) => {
      console.error('[WebSocket] Error:', error);
    });

    return () => {
      socket.disconnect();
    };
  }, [role, token, onNotification, onConnect, onDisconnect]);

  const sendNotification = useCallback((notification: Omit<NotificationPayload, 'timestamp'>) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('admin:notify', {
        ...notification,
        timestamp: new Date(),
      });
    }
  }, []);

  const sendForumMessage = useCallback((data: { message: string; username: string; memberId: number }) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('forum:message', data);
    }
  }, []);

  const sendRunnerMessage = useCallback((data: { subject: string; message: string; runnerId: number }) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('runner:message', data);
    }
  }, []);

  const sendStatusUpdate = useCallback((data: { status: string; details?: Record<string, unknown> }) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('status:update', data);
    }
  }, []);

  const sendCriticalAlert = useCallback((data: { title: string; content: string; details?: Record<string, unknown> }) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('alert:critical', data);
    }
  }, []);

  const updatePresence = useCallback((status: 'online' | 'away' | 'offline') => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('presence:update', { status });
    }
  }, []);

  const startTyping = useCallback((channel: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('typing:start', { channel });
    }
  }, []);

  const stopTyping = useCallback((channel: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('typing:stop', { channel });
    }
  }, []);

  const subscribe = useCallback((channel: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('subscribe', { channel });
    }
  }, []);

  const unsubscribe = useCallback((channel: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('unsubscribe', { channel });
    }
  }, []);

  return {
    isConnected,
    notifications,
    sendNotification,
    sendForumMessage,
    sendRunnerMessage,
    sendStatusUpdate,
    sendCriticalAlert,
    updatePresence,
    startTyping,
    stopTyping,
    subscribe,
    unsubscribe,
    socket: socketRef.current,
  };
}
