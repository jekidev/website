import { createContext, useContext, ReactNode, useState, useCallback } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';

interface Notification {
  type: 'message' | 'alert' | 'status' | 'forum' | 'admin' | 'system';
  title: string;
  content: string;
  timestamp: Date;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  targetRole?: 'admin' | 'runner' | 'member' | 'all';
  data?: Record<string, unknown>;
}

interface WebSocketContextType {
  isConnected: boolean;
  notifications: Notification[];
  dismissNotification: (index: number) => void;
  sendNotification: (notification: Omit<Notification, 'timestamp'>) => void;
  sendForumMessage: (data: { message: string; username: string; memberId: number }) => void;
  sendRunnerMessage: (data: { subject: string; message: string; runnerId: number }) => void;
  sendStatusUpdate: (data: { status: string; details?: Record<string, unknown> }) => void;
  sendCriticalAlert: (data: { title: string; content: string; details?: Record<string, unknown> }) => void;
  updatePresence: (status: 'online' | 'away' | 'offline') => void;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

interface WebSocketProviderProps {
  children: ReactNode;
  role: 'admin' | 'runner' | 'member';
  token?: string;
}

export function WebSocketProvider({
  children,
  role,
  token,
}: WebSocketProviderProps) {
  const [displayedNotifications, setDisplayedNotifications] = useState<Notification[]>([]);

  const handleNotification = useCallback((notification: Notification) => {
    setDisplayedNotifications((prev) => [notification, ...prev].slice(0, 50));
  }, []);

  const {
    isConnected,
    notifications,
    sendNotification,
    sendForumMessage,
    sendRunnerMessage,
    sendStatusUpdate,
    sendCriticalAlert,
    updatePresence,
  } = useWebSocket({
    role,
    token,
    onNotification: handleNotification,
  });

  const dismissNotification = useCallback((index: number) => {
    setDisplayedNotifications((prev) => prev.filter((_, i) => i !== index));
  }, []);

  return (
    <WebSocketContext.Provider
      value={{
        isConnected,
        notifications: displayedNotifications,
        dismissNotification,
        sendNotification,
        sendForumMessage,
        sendRunnerMessage,
        sendStatusUpdate,
        sendCriticalAlert,
        updatePresence,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocketContext() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocketContext must be used within WebSocketProvider');
  }
  return context;
}
