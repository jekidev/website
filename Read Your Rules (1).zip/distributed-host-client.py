#!/usr/bin/env python3

"""
Distributed Website Hosting Client
TEST USE ONLY - For authorized red team testing within defined scope

Silent background script that:
1. Automatically registers with GitHub
2. Monitors a central JSON file for hosting assignments
3. Silently starts ngrok tunnel when assigned
4. Hosts website via local HTTP server
"""

import os
import sys
import json
import time
import subprocess
import threading
import http.server
import socketserver
import requests
from pathlib import Path
from datetime import datetime

try:
    from pyngrok import ngrok
except ImportError:
    print("Installing pyngrok...")
    subprocess.run([sys.executable, "-m", "pip", "install", "pyngrok", "requests"], check=True)
    from pyngrok import ngrok


class DistributedHostClient:
    """Silent distributed hosting client."""

    def __init__(self):
        self.config_dir = Path(os.getenv('APPDATA', os.path.expanduser('~/.config'))) / "KBHNight"
        self.config_file = self.config_dir / "config.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.my_name = None
        self.github_token = None
        self.ngrok_token = None
        self.json_url = None
        self.is_hosting = False
        self.server = None
        self.port = 8000

    def setup(self):
        """Initial setup - register with GitHub and get tokens."""
        if self.config_file.exists():
            self.load_config()
            return

        print("=== KBH@NIGHT Distributed Hosting Setup ===")
        print("TEST USE ONLY - Authorized Testing Framework\n")

        self.my_name = input("Enter your forum username: ").strip()
        self.github_token = input("Enter your GitHub Team Token: ").strip()
        self.ngrok_token = input("Enter your ngrok auth token (from dashboard.ngrok.com): ").strip()
        self.json_url = input("Enter the GitHub JSON URL (e.g., https://raw.githubusercontent.com/...): ").strip()

        self.save_config()
        print("\n✓ Configuration saved! Script will now run silently in background.")

    def save_config(self):
        """Save configuration to disk."""
        config = {
            "username": self.my_name,
            "github_token": self.github_token,
            "ngrok_token": self.ngrok_token,
            "json_url": self.json_url,
            "created": datetime.now().isoformat()
        }
        with open(self.config_file, "w") as f:
            json.dump(config, f, indent=2)
        os.chmod(self.config_file, 0o600)  # Restrict permissions

    def load_config(self):
        """Load configuration from disk."""
        with open(self.config_file, "r") as f:
            config = json.load(f)
        self.my_name = config["username"]
        self.github_token = config["github_token"]
        self.ngrok_token = config["ngrok_token"]
        self.json_url = config["json_url"]

    def check_if_my_turn(self):
        """Check if it's my turn to host."""
        try:
            response = requests.get(self.json_url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get("current_host") == self.my_name
        except:
            pass
        return False

    def start_hosting(self):
        """Start hosting the website."""
        try:
            # Setup ngrok
            ngrok.set_auth_token(self.ngrok_token)
            
            # Start local HTTP server
            handler = http.server.SimpleHTTPRequestHandler
            self.server = socketserver.TCPServer(("", self.port), handler)
            
            # Create ngrok tunnel
            public_url = ngrok.connect(self.port).public_url
            
            # Log the public URL
            log_file = self.config_dir / "hosting_log.txt"
            with open(log_file, "a") as f:
                f.write(f"[{datetime.now()}] Hosting started: {public_url}\n")
            
            self.is_hosting = True
            self.server.serve_forever()
        except Exception as e:
            print(f"Hosting error: {e}")
            self.is_hosting = False

    def stop_hosting(self):
        """Stop hosting the website."""
        try:
            if self.server:
                self.server.shutdown()
            ngrok.kill()
            self.is_hosting = False
            
            log_file = self.config_dir / "hosting_log.txt"
            with open(log_file, "a") as f:
                f.write(f"[{datetime.now()}] Hosting stopped\n")
        except:
            pass

    def run(self):
        """Main loop - monitor and host."""
        print(f"Monitoring for hosting assignments for: {self.my_name}")
        
        while True:
            try:
                my_turn = self.check_if_my_turn()
                
                if my_turn and not self.is_hosting:
                    print(f"[{datetime.now()}] It's my turn! Starting hosting...")
                    threading.Thread(target=self.start_hosting, daemon=True).start()
                
                elif not my_turn and self.is_hosting:
                    print(f"[{datetime.now()}] My turn ended. Stopping hosting...")
                    self.stop_hosting()
                
                time.sleep(300)  # Check every 5 minutes
            except Exception as e:
                print(f"Error in main loop: {e}")
                time.sleep(300)


def create_startup_script():
    """Create a startup script for Windows."""
    if sys.platform != "win32":
        return

    startup_dir = Path(os.getenv('APPDATA')) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    vbs_script = startup_dir / "kbh_host.vbs"

    vbs_content = f'''
Set objShell = CreateObject("WScript.Shell")
objShell.Run "python.exe ""{os.path.abspath(__file__)}"" ", 0, False
'''

    try:
        with open(vbs_script, "w") as f:
            f.write(vbs_content)
        print(f"✓ Startup script created: {vbs_script}")
    except:
        print("Could not create startup script")


def main():
    """Main entry point."""
    client = DistributedHostClient()
    
    # First run setup if needed
    if not client.config_file.exists():
        client.setup()
    else:
        client.load_config()
    
    # Create startup script on Windows
    if sys.platform == "win32":
        create_startup_script()
    
    # Run the main loop
    try:
        client.run()
    except KeyboardInterrupt:
        print("\nShutting down...")
        client.stop_hosting()
        sys.exit(0)


if __name__ == "__main__":
    main()
