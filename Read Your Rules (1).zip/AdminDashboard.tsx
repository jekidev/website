import { useState, useEffect } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, Plus, Trash2, Edit2, Settings, Users, Link2, Download } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

/**
 * KBH@NIGHT Admin Dashboard
 * TEST USE ONLY - For authorized red team testing within defined scope
 */

export default function AdminDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('members');
  const [showDialog, setShowDialog] = useState(false);
  const [dialogType, setDialogType] = useState<'member' | 'clone' | 'phishing' | 'malware'>('member');

  // Form states
  const [memberForm, setMemberForm] = useState({ username: '', role: 'member' as const });
  const [cloneForm, setCloneForm] = useState({ name: '', clonedUrl: '', originalUrl: '', rotationSchedule: '' });
  const [phishingForm, setPhishingForm] = useState({ name: '', targetUrl: '', triggerFailedAttempts: 3 });
  const [malwareForm, setMalwareForm] = useState({
    name: '',
    description: '',
    downloadUrl: '',
    version: '',
    requiredRole: 'member' as const,
    weekendAccessOnly: false,
  });

  // Redirect if not admin
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">ACCESS DENIED</h1>
          <p className="text-gray-400">Admin privileges required</p>
        </div>
      </div>
    );
  }

  const createMemberMutation = trpc.operational.createMember.useMutation({
    onSuccess: () => {
      toast.success('Member created successfully');
      setMemberForm({ username: '', role: 'member' });
      setShowDialog(false);
    },
    onError: () => {
      toast.error('Failed to create member');
    },
  });

  const handleCreateMember = async () => {
    createMemberMutation.mutate({
      username: memberForm.username,
      role: memberForm.role,
    });
  };

  const createCloneMutation = trpc.operational.createSiteClone.useMutation({
    onSuccess: () => {
      toast.success('Site clone created successfully');
      setCloneForm({ name: '', clonedUrl: '', originalUrl: '', rotationSchedule: '' });
      setShowDialog(false);
    },
    onError: () => {
      toast.error('Failed to create site clone');
    },
  });

  const handleCreateSiteClone = async () => {
    createCloneMutation.mutate({
      name: cloneForm.name,
      clonedUrl: cloneForm.clonedUrl,
      originalUrl: cloneForm.originalUrl,
      rotationSchedule: cloneForm.rotationSchedule,
    });
  };

  const createPhishingMutation = trpc.operational.createPhishingRedirect.useMutation({
    onSuccess: () => {
      toast.success('Phishing redirect created successfully');
      setPhishingForm({ name: '', targetUrl: '', triggerFailedAttempts: 3 });
      setShowDialog(false);
    },
    onError: () => {
      toast.error('Failed to create phishing redirect');
    },
  });

  const handleCreatePhishingRedirect = async () => {
    createPhishingMutation.mutate({
      name: phishingForm.name,
      targetUrl: phishingForm.targetUrl,
      triggerFailedAttempts: phishingForm.triggerFailedAttempts,
    });
  };

  const createMalwareMutation = trpc.operational.createMalwareDistribution.useMutation({
    onSuccess: () => {
      toast.success('Malware distribution created successfully');
      setMalwareForm({
        name: '',
        description: '',
        downloadUrl: '',
        version: '',
        requiredRole: 'member',
        weekendAccessOnly: false,
      });
      setShowDialog(false);
    },
    onError: () => {
      toast.error('Failed to create malware distribution');
    },
  });

  const handleCreateMalwareDistribution = async () => {
    createMalwareMutation.mutate({
      name: malwareForm.name,
      description: malwareForm.description,
      downloadUrl: malwareForm.downloadUrl,
      version: malwareForm.version,
      requiredRole: malwareForm.requiredRole,
      weekendAccessOnly: malwareForm.weekendAccessOnly,
    });
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-white/10 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold font-mono tracking-widest">COMMAND CENTER</h1>
              <p className="text-sm text-gray-400 mt-1">TEST USE ONLY - Authorized Testing Framework</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400">Admin: {user?.name}</p>
              <p className="text-xs text-cyan-400 font-mono">ENCRYPTED SESSION</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white/5 border border-white/10">
            <TabsTrigger value="members" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Members</span>
            </TabsTrigger>
            <TabsTrigger value="clones" className="flex items-center gap-2">
              <Link2 className="w-4 h-4" />
              <span className="hidden sm:inline">Site Clones</span>
            </TabsTrigger>
            <TabsTrigger value="phishing" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span className="hidden sm:inline">Phishing</span>
            </TabsTrigger>
            <TabsTrigger value="malware" className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Malware</span>
            </TabsTrigger>
          </TabsList>

          {/* Members Tab */}
          <TabsContent value="members" className="space-y-6 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Member Management</h2>
              <Button
                onClick={() => {
                  setDialogType('member');
                  setShowDialog(true);
                }}
                className="bg-white text-black hover:bg-gray-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </div>

            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle>Active Members</CardTitle>
                <CardDescription>Manage collective members and their access levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="grid grid-cols-4 gap-4 text-sm font-mono text-gray-400 border-b border-white/10 pb-3">
                    <div>Username</div>
                    <div>Role</div>
                    <div>Status</div>
                    <div>Actions</div>
                  </div>
                  <div className="text-sm text-gray-500 py-4 text-center">
                    Loading members...
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Site Clones Tab */}
          <TabsContent value="clones" className="space-y-6 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Site Cloning Configuration</h2>
              <Button
                onClick={() => {
                  setDialogType('clone');
                  setShowDialog(true);
                }}
                className="bg-white text-black hover:bg-gray-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Clone
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle>Active Clone</CardTitle>
                  <CardDescription>Currently deployed site</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-black/50 rounded border border-cyan-400/30">
                      <p className="text-sm text-gray-400">No active clone</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle>Rotation Schedule</CardTitle>
                  <CardDescription>Automated site rotation</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-4 bg-black/50 rounded border border-white/10">
                      <p className="text-sm text-gray-400">No rotation scheduled</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Phishing Tab */}
          <TabsContent value="phishing" className="space-y-6 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Phishing Redirection</h2>
              <Button
                onClick={() => {
                  setDialogType('phishing');
                  setShowDialog(true);
                }}
                className="bg-white text-black hover:bg-gray-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Redirect
              </Button>
            </div>

            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle>Phishing Redirects</CardTitle>
                <CardDescription>Failed auth attempt redirection targets</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-gray-500 py-4 text-center">
                    No phishing redirects configured
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Malware Tab */}
          <TabsContent value="malware" className="space-y-6 mt-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Malware Distribution</h2>
              <Button
                onClick={() => {
                  setDialogType('malware');
                  setShowDialog(true);
                }}
                className="bg-white text-black hover:bg-gray-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Distribution
              </Button>
            </div>

            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle>Available Downloads</CardTitle>
                <CardDescription>Managed malware distribution links</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-gray-500 py-4 text-center">
                    No malware distributions configured
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-black border border-white/10 backdrop-blur-xl max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">
              {dialogType === 'member' && 'Add New Member'}
              {dialogType === 'clone' && 'Create Site Clone'}
              {dialogType === 'phishing' && 'Create Phishing Redirect'}
              {dialogType === 'malware' && 'Add Malware Distribution'}
            </DialogTitle>
            <DialogDescription>TEST USE ONLY - Authorized testing framework</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {dialogType === 'member' && (
              <>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Username</label>
                  <Input
                    value={memberForm.username}
                    onChange={(e) => setMemberForm({ ...memberForm, username: e.target.value })}
                    placeholder="member_username"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Role</label>
                  <Select value={memberForm.role} onValueChange={(role: any) => setMemberForm({ ...memberForm, role })}>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="member">Member</SelectItem>
                      <SelectItem value="operator">Operator</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleCreateMember} className="w-full bg-white text-black hover:bg-gray-200">
                  Create Member
                </Button>
              </>
            )}

            {dialogType === 'clone' && (
              <>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Clone Name</label>
                  <Input
                    value={cloneForm.name}
                    onChange={(e) => setCloneForm({ ...cloneForm, name: e.target.value })}
                    placeholder="Clone identifier"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Cloned URL</label>
                  <Input
                    value={cloneForm.clonedUrl}
                    onChange={(e) => setCloneForm({ ...cloneForm, clonedUrl: e.target.value })}
                    placeholder="https://cloned-site.com"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Original URL</label>
                  <Input
                    value={cloneForm.originalUrl}
                    onChange={(e) => setCloneForm({ ...cloneForm, originalUrl: e.target.value })}
                    placeholder="https://original-site.com"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <Button onClick={handleCreateSiteClone} className="w-full bg-white text-black hover:bg-gray-200">
                  Create Clone
                </Button>
              </>
            )}

            {dialogType === 'phishing' && (
              <>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Redirect Name</label>
                  <Input
                    value={phishingForm.name}
                    onChange={(e) => setPhishingForm({ ...phishingForm, name: e.target.value })}
                    placeholder="Phishing target"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Target URL</label>
                  <Input
                    value={phishingForm.targetUrl}
                    onChange={(e) => setPhishingForm({ ...phishingForm, targetUrl: e.target.value })}
                    placeholder="https://phishing-site.com"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Failed Attempts Trigger</label>
                  <Input
                    type="number"
                    value={phishingForm.triggerFailedAttempts}
                    onChange={(e) => setPhishingForm({ ...phishingForm, triggerFailedAttempts: parseInt(e.target.value) })}
                    placeholder="3"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <Button onClick={handleCreatePhishingRedirect} className="w-full bg-white text-black hover:bg-gray-200">
                  Create Redirect
                </Button>
              </>
            )}

            {dialogType === 'malware' && (
              <>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Program Name</label>
                  <Input
                    value={malwareForm.name}
                    onChange={(e) => setMalwareForm({ ...malwareForm, name: e.target.value })}
                    placeholder="Program name"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Download URL</label>
                  <Input
                    value={malwareForm.downloadUrl}
                    onChange={(e) => setMalwareForm({ ...malwareForm, downloadUrl: e.target.value })}
                    placeholder="https://download-link.com/file"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-2">Weekend Access Only</label>
                  <Select value={malwareForm.weekendAccessOnly ? 'yes' : 'no'} onValueChange={(val) => setMalwareForm({ ...malwareForm, weekendAccessOnly: val === 'yes' })}>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="no">No</SelectItem>
                      <SelectItem value="yes">Yes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleCreateMalwareDistribution} className="w-full bg-white text-black hover:bg-gray-200">
                  Add Distribution
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
