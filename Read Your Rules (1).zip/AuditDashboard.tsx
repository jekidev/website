import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { auditLogger, AuditLogEntry } from '@/lib/auditLog';
import { FileText, Download, Filter, AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';

/**
 * KBH@NIGHT Audit Dashboard
 * Design Philosophy: Compliance & Monitoring Interface
 * - Encrypted audit log viewing
 * - Operational tracking
 * - Security event monitoring
 * - Report generation
 */

interface AuditStats {
  totalEntries: number;
  successCount: number;
  failureCount: number;
  warningCount: number;
  uniqueActors: number;
}

export default function AuditDashboard() {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [stats, setStats] = useState<AuditStats>({
    totalEntries: 0,
    successCount: 0,
    failureCount: 0,
    warningCount: 0,
    uniqueActors: 0,
  });

  const [filterAction, setFilterAction] = useState('');
  const [filterActor, setFilterActor] = useState('');
  const [filterStatus, setFilterStatus] = useState<'success' | 'failure' | 'warning' | ''>('');
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);
  const [decryptedDetails, setDecryptedDetails] = useState<Record<string, unknown>>({});

  // Load logs on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const allLogs = await auditLogger.getLogs();
        setLogs(allLogs);

        const logStats = await auditLogger.getStatistics();
        setStats({
          totalEntries: logStats.totalEntries,
          successCount: logStats.successCount,
          failureCount: logStats.failureCount,
          warningCount: logStats.warningCount,
          uniqueActors: logStats.uniqueActors,
        });
      } catch (error) {
        console.error('Failed to load audit logs:', error);
      }
    };

    loadData();
  }, []);

  const filteredLogs = logs.filter(log => {
    if (filterAction && log.action !== filterAction) return false;
    if (filterActor && log.actor !== filterActor) return false;
    if (filterStatus && log.status !== filterStatus) return false;
    return true;
  });

  const handleViewDetails = async (log: AuditLogEntry) => {
    setSelectedLog(log);
    try {
      const details = await auditLogger.decryptLogDetails(log);
      setDecryptedDetails(details);
    } catch (error) {
      console.error('Failed to decrypt details:', error);
      setDecryptedDetails(log.details);
    }
    setShowDetailDialog(true);
  };

  const handleExportReport = async () => {
    try {
      const report = await auditLogger.generateReport({
        action: filterAction || undefined,
        actor: filterActor || undefined,
        status: (filterStatus as any) || undefined,
      });

      const blob = new Blob([report], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-report-${Date.now()}.txt`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export report:', error);
    }
  };

  const handleExportJSON = async () => {
    try {
      const json = await auditLogger.exportLogs();
      const blob = new Blob([json], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-logs-${Date.now()}.json`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export JSON:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case 'failure':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-black">
      <video
        autoPlay
        muted
        loop
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'brightness(0.3) contrast(1.2)' }}
      >
        <source src="/grok-video-4edfd5f3-4559-46c4-867a-516d1af9088a.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/80" />

      <div className="relative z-10 min-h-screen px-4 sm:px-8 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl sm:text-5xl font-light tracking-tight text-white mb-2" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
              AUDIT LOGS
            </h1>
            <div className="h-px w-40 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
          </div>

          {/* Statistics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">TOTAL ENTRIES</div>
              <div className="text-2xl font-bold text-cyan-400">{stats.totalEntries}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">SUCCESS</div>
              <div className="text-2xl font-bold text-emerald-400">{stats.successCount}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">FAILURES</div>
              <div className="text-2xl font-bold text-red-400">{stats.failureCount}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">WARNINGS</div>
              <div className="text-2xl font-bold text-amber-400">{stats.warningCount}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">UNIQUE ACTORS</div>
              <div className="text-2xl font-bold text-purple-400">{stats.uniqueActors}</div>
            </div>
          </div>

          {/* Filters and Export */}
          <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Filter className="w-5 h-5 text-cyan-400" />
              <h2 className="text-lg font-light tracking-widest text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                FILTERS
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <input
                type="text"
                placeholder="Filter by action..."
                value={filterAction}
                onChange={(e) => setFilterAction(e.target.value)}
                className="bg-black/30 border border-white/10 rounded px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:border-white/30"
              />
              <input
                type="text"
                placeholder="Filter by actor..."
                value={filterActor}
                onChange={(e) => setFilterActor(e.target.value)}
                className="bg-black/30 border border-white/10 rounded px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:border-white/30"
              />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="bg-black/30 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-white/30"
              >
                <option value="">All Statuses</option>
                <option value="success">Success</option>
                <option value="failure">Failure</option>
                <option value="warning">Warning</option>
              </select>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => {
                  setFilterAction('');
                  setFilterActor('');
                  setFilterStatus('');
                }}
                className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold px-4 py-2 rounded text-sm"
              >
                CLEAR FILTERS
              </Button>
              <Button
                onClick={handleExportReport}
                className="bg-cyan-600/20 hover:bg-cyan-600/40 border border-cyan-500/50 text-cyan-400 font-semibold px-4 py-2 rounded text-sm flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                EXPORT REPORT
              </Button>
              <Button
                onClick={handleExportJSON}
                className="bg-cyan-600/20 hover:bg-cyan-600/40 border border-cyan-500/50 text-cyan-400 font-semibold px-4 py-2 rounded text-sm flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                EXPORT JSON
              </Button>
            </div>
          </div>

          {/* Logs Table */}
          <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm overflow-x-auto">
            <h2 className="text-lg font-light tracking-widest text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
              ENTRIES ({filteredLogs.length})
            </h2>

            <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar">
              {filteredLogs.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  No logs found matching filters
                </div>
              ) : (
                filteredLogs.map(log => (
                  <div
                    key={log.id}
                    onClick={() => handleViewDetails(log)}
                    className="bg-black/30 border border-white/10 rounded p-4 hover:border-white/30 cursor-pointer transition-all flex justify-between items-start"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {getStatusIcon(log.status)}
                        <span className="font-mono text-sm text-white font-semibold">{log.action}</span>
                        <span className="text-xs text-gray-400">{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                      <div className="text-xs text-gray-400 space-y-1">
                        <div>Actor: <span className="text-cyan-400">{log.actor}</span></div>
                        <div>Target: <span className="text-cyan-400">{log.target}</span></div>
                      </div>
                    </div>
                    <div className={`text-xs px-2 py-1 rounded font-mono ${
                      log.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                      log.status === 'failure' ? 'bg-red-500/20 text-red-400' :
                      'bg-amber-500/20 text-amber-400'
                    }`}>
                      {log.status.toUpperCase()}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Details Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-2xl shadow-2xl max-h-96 overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg font-light tracking-widest text-white">
              LOG ENTRY DETAILS
            </DialogTitle>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs font-mono text-gray-400 mb-1">ACTION</div>
                  <div className="text-sm text-white">{selectedLog.action}</div>
                </div>
                <div>
                  <div className="text-xs font-mono text-gray-400 mb-1">STATUS</div>
                  <div className={`text-sm px-2 py-1 rounded inline-block font-mono ${
                    selectedLog.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                    selectedLog.status === 'failure' ? 'bg-red-500/20 text-red-400' :
                    'bg-amber-500/20 text-amber-400'
                  }`}>
                    {selectedLog.status.toUpperCase()}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-mono text-gray-400 mb-1">ACTOR</div>
                  <div className="text-sm text-cyan-400">{selectedLog.actor}</div>
                </div>
                <div>
                  <div className="text-xs font-mono text-gray-400 mb-1">TARGET</div>
                  <div className="text-sm text-cyan-400">{selectedLog.target}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs font-mono text-gray-400 mb-1">TIMESTAMP</div>
                  <div className="text-sm text-white">{new Date(selectedLog.timestamp).toISOString()}</div>
                </div>
              </div>

              <div>
                <div className="text-xs font-mono text-gray-400 mb-2">DETAILS</div>
                <div className="bg-black/50 border border-white/10 rounded p-3 max-h-40 overflow-y-auto">
                  <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap break-words">
                    {JSON.stringify(decryptedDetails, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(34, 211, 238, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(34, 211, 238, 0.5);
        }
      `}</style>
    </div>
  );
}
