import { encryptionService } from './encryption';

/**
 * KBH@NIGHT Audit Logging System
 * Encrypted logging for compliance and operational tracking
 * 
 * TEST USE ONLY - For authorized red team testing within defined scope
 */

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  action: string;
  actor: string;
  target: string;
  status: 'success' | 'failure' | 'warning';
  details: Record<string, unknown>;
  ipAddress?: string;
  sessionToken?: string;
  encryptedDetails?: string;
}

export interface AuditLogFilter {
  startTime?: number;
  endTime?: number;
  action?: string;
  actor?: string;
  status?: 'success' | 'failure' | 'warning';
}

/**
 * Encrypted Audit Logger
 * Maintains encrypted logs for operational tracking and compliance
 */
export class AuditLogger {
  private logs: AuditLogEntry[] = [];
  private maxLogs: number = 10000;
  private storageKey: string = 'kbh_audit_logs';

  constructor() {
    this.loadLogs();
  }

  /**
   * Load logs from secure storage
   */
  private async loadLogs(): Promise<void> {
    try {
      const stored = await encryptionService.secureRetrieve<AuditLogEntry[]>(this.storageKey);
      if (stored) {
        this.logs = stored;
      }
    } catch (error) {
      console.error('Failed to load audit logs:', error);
    }
  }

  /**
   * Save logs to secure storage
   */
  private async saveLogs(): Promise<void> {
    try {
      // Keep only recent logs if exceeding max
      if (this.logs.length > this.maxLogs) {
        this.logs = this.logs.slice(-this.maxLogs);
      }

      await encryptionService.secureStore(this.storageKey, this.logs);
    } catch (error) {
      console.error('Failed to save audit logs:', error);
    }
  }

  /**
   * Log an action
   */
  public async log(
    action: string,
    actor: string,
    target: string,
    status: 'success' | 'failure' | 'warning' = 'success',
    details: Record<string, unknown> = {},
    ipAddress?: string,
    sessionToken?: string
  ): Promise<void> {
    try {
      // Encrypt sensitive details
      let encryptedDetails: string | undefined;
      if (Object.keys(details).length > 0) {
        const detailsJson = JSON.stringify(details);
        const encrypted = await encryptionService.encrypt(detailsJson);
        encryptedDetails = JSON.stringify(encrypted);
      }

      const entry: AuditLogEntry = {
        id: encryptionService.generateToken(16),
        timestamp: Date.now(),
        action,
        actor,
        target,
        status,
        details,
        ipAddress,
        sessionToken,
        encryptedDetails,
      };

      this.logs.push(entry);
      await this.saveLogs();
    } catch (error) {
      console.error('Failed to log action:', error);
    }
  }

  /**
   * Log authentication attempt
   */
  public async logAuthentication(
    username: string,
    success: boolean,
    ipAddress?: string
  ): Promise<void> {
    await this.log(
      'AUTHENTICATION',
      username,
      'AUTH_SYSTEM',
      success ? 'success' : 'failure',
      { method: 'password', success },
      ipAddress
    );
  }

  /**
   * Log member management action
   */
  public async logMemberAction(
    actor: string,
    action: 'CREATE' | 'UPDATE' | 'DELETE' | 'PROMOTE' | 'DEMOTE',
    memberId: string,
    details: Record<string, unknown> = {}
  ): Promise<void> {
    await this.log(
      `MEMBER_${action}`,
      actor,
      memberId,
      'success',
      details
    );
  }

  /**
   * Log message broadcast
   */
  public async logMessageBroadcast(
    actor: string,
    groupCount: number,
    recipientCount: number,
    status: 'success' | 'failure' | 'warning' = 'success'
  ): Promise<void> {
    await this.log(
      'MESSAGE_BROADCAST',
      actor,
      'SIGNAL_SYSTEM',
      status,
      { groups: groupCount, recipients: recipientCount }
    );
  }

  /**
   * Log data access
   */
  public async logDataAccess(
    actor: string,
    dataType: string,
    recordCount: number
  ): Promise<void> {
    await this.log(
      'DATA_ACCESS',
      actor,
      dataType,
      'success',
      { records: recordCount }
    );
  }

  /**
   * Log security event
   */
  public async logSecurityEvent(
    event: string,
    severity: 'low' | 'medium' | 'high' | 'critical',
    details: Record<string, unknown> = {}
  ): Promise<void> {
    const statusMap = {
      low: 'warning',
      medium: 'warning',
      high: 'failure',
      critical: 'failure',
    } as const;

    await this.log(
      `SECURITY_${event}`,
      'SYSTEM',
      'SECURITY_MONITOR',
      statusMap[severity],
      { severity, ...details }
    );
  }

  /**
   * Get logs with optional filtering
   */
  public async getLogs(filter?: AuditLogFilter): Promise<AuditLogEntry[]> {
    let filtered = [...this.logs];

    if (filter) {
      if (filter.startTime) {
        filtered = filtered.filter(log => log.timestamp >= filter.startTime!);
      }
      if (filter.endTime) {
        filtered = filtered.filter(log => log.timestamp <= filter.endTime!);
      }
      if (filter.action) {
        filtered = filtered.filter(log => log.action === filter.action);
      }
      if (filter.actor) {
        filtered = filtered.filter(log => log.actor === filter.actor);
      }
      if (filter.status) {
        filtered = filtered.filter(log => log.status === filter.status);
      }
    }

    return filtered;
  }

  /**
   * Get recent logs
   */
  public async getRecentLogs(count: number = 100): Promise<AuditLogEntry[]> {
    return this.logs.slice(-count);
  }

  /**
   * Decrypt log details
   */
  public async decryptLogDetails(entry: AuditLogEntry): Promise<Record<string, unknown>> {
    if (!entry.encryptedDetails) {
      return entry.details;
    }

    try {
      const encrypted = JSON.parse(entry.encryptedDetails);
      const decrypted = await encryptionService.decrypt(encrypted);
      return JSON.parse(decrypted);
    } catch (error) {
      console.error('Failed to decrypt log details:', error);
      return entry.details;
    }
  }

  /**
   * Generate audit report
   */
  public async generateReport(filter?: AuditLogFilter): Promise<string> {
    const logs = await this.getLogs(filter);

    let report = '=== KBH@NIGHT AUDIT REPORT ===\n';
    report += `Generated: ${new Date().toISOString()}\n`;
    report += `Total Entries: ${logs.length}\n\n`;

    // Summary statistics
    const successCount = logs.filter(l => l.status === 'success').length;
    const failureCount = logs.filter(l => l.status === 'failure').length;
    const warningCount = logs.filter(l => l.status === 'warning').length;

    report += '--- SUMMARY ---\n';
    report += `Success: ${successCount}\n`;
    report += `Failure: ${failureCount}\n`;
    report += `Warning: ${warningCount}\n\n`;

    // Action breakdown
    const actionCounts = new Map<string, number>();
    logs.forEach(log => {
      actionCounts.set(log.action, (actionCounts.get(log.action) || 0) + 1);
    });

    report += '--- ACTIONS ---\n';
    actionCounts.forEach((count, action) => {
      report += `${action}: ${count}\n`;
    });

    report += '\n--- RECENT ENTRIES ---\n';
    logs.slice(-20).forEach(log => {
      report += `[${new Date(log.timestamp).toISOString()}] ${log.action} - ${log.actor} -> ${log.target} (${log.status})\n`;
    });

    return report;
  }

  /**
   * Clear logs (requires confirmation)
   */
  public async clearLogs(confirmationToken: string): Promise<boolean> {
    // In production, verify confirmation token
    if (confirmationToken === 'CLEAR_AUDIT_LOGS_CONFIRMED') {
      this.logs = [];
      await this.saveLogs();
      return true;
    }
    return false;
  }

  /**
   * Export logs as JSON
   */
  public async exportLogs(): Promise<string> {
    return JSON.stringify(this.logs, null, 2);
  }

  /**
   * Get statistics
   */
  public async getStatistics(): Promise<{
    totalEntries: number;
    successCount: number;
    failureCount: number;
    warningCount: number;
    uniqueActors: number;
    dateRange: { start: number; end: number };
  }> {
    const successCount = this.logs.filter(l => l.status === 'success').length;
    const failureCount = this.logs.filter(l => l.status === 'failure').length;
    const warningCount = this.logs.filter(l => l.status === 'warning').length;

    const actors = new Set(this.logs.map(l => l.actor));

    return {
      totalEntries: this.logs.length,
      successCount,
      failureCount,
      warningCount,
      uniqueActors: actors.size,
      dateRange: {
        start: this.logs[0]?.timestamp || 0,
        end: this.logs[this.logs.length - 1]?.timestamp || 0,
      },
    };
  }
}

// Export singleton instance
export const auditLogger = new AuditLogger();
