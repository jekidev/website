import { useState, useCallback, useEffect } from 'react';
import { encryptionService, EncryptionService } from '@/lib/encryption';

/**
 * Secure Credential Management Hook
 * Handles encrypted credential storage and validation
 * 
 * TEST USE ONLY - For authorized red team testing
 */

interface SecureCredential {
  username: string;
  isAuthenticated: boolean;
  lastAuthenticated: number | null;
  sessionToken: string | null;
}

export function useSecureCredentials() {
  const [credential, setCredential] = useState<SecureCredential>({
    username: '',
    isAuthenticated: false,
    lastAuthenticated: null,
    sessionToken: null,
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Initialize credentials from secure storage
   */
  useEffect(() => {
    const initializeCredentials = async () => {
      try {
        const stored = await encryptionService.secureRetrieve<SecureCredential>(
          'kbh_credential_session'
        );

        if (stored && stored.isAuthenticated) {
          // Validate session token age (24 hour expiry)
          const sessionAge = Date.now() - (stored.lastAuthenticated || 0);
          const maxAge = 24 * 60 * 60 * 1000; // 24 hours

          if (sessionAge < maxAge) {
            setCredential(stored);
          } else {
            // Session expired
            await clearCredentials();
          }
        }
      } catch (err) {
        console.error('Failed to initialize credentials:', err);
      }
    };

    initializeCredentials();
  }, []);

  /**
   * Authenticate with password
   */
  const authenticate = useCallback(
    async (username: string, password: string): Promise<boolean> => {
      setIsLoading(true);
      setError(null);

      try {
        // Create credential vault
        const vault = await encryptionService.createCredentialVault(username, password);

        // Validate credentials
        const isValid = await encryptionService.validateCredential(vault, password);

        if (isValid) {
          // Generate session token
          const sessionToken = encryptionService.generateToken(32);

          const newCredential: SecureCredential = {
            username,
            isAuthenticated: true,
            lastAuthenticated: Date.now(),
            sessionToken,
          };

          // Store encrypted credential
          await encryptionService.secureStore('kbh_credential_session', newCredential);

          setCredential(newCredential);
          return true;
        } else {
          setError('Invalid credentials');
          return false;
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Authentication failed';
        setError(errorMessage);
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  /**
   * Validate current session
   */
  const validateSession = useCallback((): boolean => {
    if (!credential.isAuthenticated || !credential.lastAuthenticated) {
      return false;
    }

    // Check session age (24 hour expiry)
    const sessionAge = Date.now() - credential.lastAuthenticated;
    const maxAge = 24 * 60 * 60 * 1000;

    return sessionAge < maxAge;
  }, [credential]);

  /**
   * Refresh session token
   */
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (!validateSession()) {
      setError('Session expired');
      return false;
    }

    try {
      const newToken = encryptionService.generateToken(32);
      const updated: SecureCredential = {
        ...credential,
        sessionToken: newToken,
        lastAuthenticated: Date.now(),
      };

      await encryptionService.secureStore('kbh_credential_session', updated);
      setCredential(updated);
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Session refresh failed';
      setError(errorMessage);
      return false;
    }
  }, [credential, validateSession]);

  /**
   * Clear credentials and logout
   */
  const clearCredentials = useCallback(async (): Promise<void> => {
    try {
      // Securely clear session storage
      localStorage.removeItem('kbh_credential_session');

      setCredential({
        username: '',
        isAuthenticated: false,
        lastAuthenticated: null,
        sessionToken: null,
      });

      setError(null);
    } catch (err) {
      console.error('Failed to clear credentials:', err);
    }
  }, []);

  /**
   * Encrypt sensitive data with current session
   */
  const encryptData = useCallback(
    async (data: unknown): Promise<string | null> => {
      if (!validateSession()) {
        setError('Session expired');
        return null;
      }

      try {
        const jsonString = JSON.stringify(data);
        const encrypted = await encryptionService.encrypt(jsonString, credential.sessionToken || '');
        return JSON.stringify(encrypted);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Encryption failed';
        setError(errorMessage);
        return null;
      }
    },
    [credential.sessionToken, validateSession]
  );

  /**
   * Decrypt sensitive data with current session
   */
  const decryptData = useCallback(
    async <T = unknown>(encryptedString: string): Promise<T | null> => {
      if (!validateSession()) {
        setError('Session expired');
        return null;
      }

      try {
        const encrypted = JSON.parse(encryptedString);
        const decrypted = await encryptionService.decrypt(encrypted, credential.sessionToken || '');
        return JSON.parse(decrypted) as T;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Decryption failed';
        setError(errorMessage);
        return null;
      }
    },
    [credential.sessionToken, validateSession]
  );

  return {
    credential,
    isLoading,
    error,
    authenticate,
    validateSession,
    refreshSession,
    clearCredentials,
    encryptData,
    decryptData,
  };
}
