#!/usr/bin/env node

/**
 * KBH@NIGHT Deployment Day Configuration Script
 * TEST USE ONLY - For authorized red team testing within defined scope
 * 
 * Usage:
 *   node scripts/configure-deployment-days.mjs --days 1,2,3,4,5
 *   node scripts/configure-deployment-days.mjs --days 0,6 (weekends)
 *   node scripts/configure-deployment-days.mjs --time 14:30 (2:30 PM UTC)
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const workflowPath = path.join(__dirname, '../.github/workflows/daily-deploy.yml');

// Parse command line arguments
const args = process.argv.slice(2);
let days = '1-5'; // Default: Monday-Friday
let time = '02:00'; // Default: 02:00 UTC
let minute = '0';
let hour = '2';

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--days' && args[i + 1]) {
    days = args[i + 1];
    i++;
  } else if (args[i] === '--time' && args[i + 1]) {
    time = args[i + 1];
    const [h, m] = time.split(':');
    hour = h || '2';
    minute = m || '0';
  } else if (args[i] === '--help') {
    console.log(`
KBH@NIGHT Deployment Day Configuration

Usage:
  node scripts/configure-deployment-days.mjs [options]

Options:
  --days <days>      Deployment days (0-6, comma-separated or range)
                     0=Sunday, 1=Monday, 2=Tuesday, 3=Wednesday,
                     4=Thursday, 5=Friday, 6=Saturday
                     Examples: "1,2,3,4,5" or "1-5" or "0,6"
  
  --time <time>      Deployment time in UTC (HH:MM format)
                     Example: "14:30" for 2:30 PM UTC
  
  --help             Show this help message

Examples:
  # Deploy Monday-Friday at 02:00 UTC
  node scripts/configure-deployment-days.mjs --days 1-5 --time 02:00
  
  # Deploy weekends at 10:00 UTC
  node scripts/configure-deployment-days.mjs --days 0,6 --time 10:00
  
  # Deploy daily at 15:30 UTC
  node scripts/configure-deployment-days.mjs --days 0-6 --time 15:30
    `);
    process.exit(0);
  }
}

// Convert day specification to cron format
function parseDays(daySpec) {
  const dayParts = daySpec.split(',');
  const dayNumbers = [];
  
  for (const part of dayParts) {
    if (part.includes('-')) {
      const [start, end] = part.split('-').map(Number);
      for (let i = start; i <= end; i++) {
        dayNumbers.push(i);
      }
    } else {
      dayNumbers.push(Number(part));
    }
  }
  
  // Remove duplicates and sort
  const unique = [...new Set(dayNumbers)].sort((a, b) => a - b);
  
  // If all 7 days, use * instead of listing
  if (unique.length === 7) {
    return '*';
  }
  
  return unique.join(',');
}

// Generate cron expression
const cronDays = parseDays(days);
const cronExpression = `${minute} ${hour} * * ${cronDays}`;

console.log(`\n📅 KBH@NIGHT Deployment Configuration`);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`Deployment Days: ${days}`);
console.log(`Deployment Time: ${time} UTC`);
console.log(`Cron Expression: ${cronExpression}`);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);

// Read current workflow file
if (!fs.existsSync(workflowPath)) {
  console.error(`❌ Workflow file not found: ${workflowPath}`);
  process.exit(1);
}

let workflowContent = fs.readFileSync(workflowPath, 'utf-8');

// Update the cron schedule in the workflow file
const cronRegex = /- cron: '[\d\s\-,*]+'/;
const newCronLine = `- cron: '${cronExpression}'`;

if (cronRegex.test(workflowContent)) {
  workflowContent = workflowContent.replace(cronRegex, newCronLine);
  fs.writeFileSync(workflowPath, workflowContent, 'utf-8');
  console.log(`✅ Workflow file updated successfully`);
  console.log(`📝 File: ${workflowPath}`);
  console.log(`\n🚀 Next deployment scheduled for:`);
  console.log(`   Days: ${days}`);
  console.log(`   Time: ${time} UTC`);
  console.log(`   Cron: ${cronExpression}`);
  console.log(`\n💡 TEST USE ONLY - Authorized testing framework\n`);
} else {
  console.error(`❌ Could not find cron schedule in workflow file`);
  process.exit(1);
}
