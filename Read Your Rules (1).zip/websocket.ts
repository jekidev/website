import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';
import { getDb } from './db';
import { eq } from 'drizzle-orm';
import { runnerMessages, forumMessages, members } from '../drizzle/schema';

interface NotificationPayload {
  type: 'message' | 'alert' | 'status' | 'forum' | 'admin' | 'system';
  title: string;
  content: string;
  timestamp: Date;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  targetRole?: 'admin' | 'runner' | 'member' | 'all';
  data?: Record<string, unknown>;
}

interface ClientContext {
  userId?: number;
  username?: string;
  role?: 'admin' | 'runner' | 'member';
  connectedAt: Date;
}

const connectedClients = new Map<string, ClientContext>();

export function initializeWebSocket(httpServer: HTTPServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.NODE_ENV === 'production' 
        ? process.env.VITE_FRONTEND_URL 
        : 'http://localhost:5173',
      credentials: true,
    },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: 5,
  });

  // Middleware for authentication
  io.use((socket: any, next: any) => {
    const token = socket.handshake.auth.token;
    const role = socket.handshake.auth.role;
    
    if (!token || !role) {
      return next(new Error('Authentication error'));
    }

    // Store client context
    connectedClients.set(socket.id, {
      role: role as 'admin' | 'runner' | 'member',
      connectedAt: new Date(),
    });

    next();
  });

  // Connection handler
  io.on('connection', (socket: Socket) => {
    const clientContext = connectedClients.get(socket.id);
    
    console.log(`[WebSocket] Client connected: ${socket.id} (${clientContext?.role})`);

    // Join role-specific room
    if (clientContext?.role) {
      socket.join(`role:${clientContext.role}`);
      socket.join('all');
    }

    // Send connection confirmation
    socket.emit('connected', {
      socketId: socket.id,
      timestamp: new Date(),
      message: 'Connected to notification service',
    });

    // Handle admin notifications
    socket.on('admin:notify', async (payload: NotificationPayload) => {
      if (clientContext?.role !== 'admin') {
        socket.emit('error', { message: 'Unauthorized' });
        return;
      }

      const notification = {
        ...payload,
        timestamp: new Date(),
        sender: clientContext.username || 'System',
      };

      // Broadcast to target audience
      if (payload.targetRole === 'all') {
        io.emit('notification', notification);
      } else if (payload.targetRole) {
        io.to(`role:${payload.targetRole}`).emit('notification', notification);
      }

      // Log to database
      await logNotification(notification);
    });

    // Handle forum messages
    socket.on('forum:message', async (data: { message: string; username: string; memberId: number }) => {
      const forumNotification: NotificationPayload = {
        type: 'forum',
        title: `New forum message from ${data.username}`,
        content: data.message,
        timestamp: new Date(),
        priority: 'medium',
        targetRole: 'all',
        data: {
          memberId: data.memberId,
          username: data.username,
        },
      };

      io.to('all').emit('notification', forumNotification);
      await logNotification(forumNotification);
    });

    // Handle runner messages
    socket.on('runner:message', async (data: { subject: string; message: string; runnerId: number }) => {
      const runnerNotification: NotificationPayload = {
        type: 'message',
        title: `Runner message: ${data.subject}`,
        content: data.message,
        timestamp: new Date(),
        priority: 'high',
        targetRole: 'admin',
        data: {
          runnerId: data.runnerId,
        },
      };

      io.to('role:admin').emit('notification', runnerNotification);
      await logNotification(runnerNotification);
    });

    // Handle status updates
    socket.on('status:update', (data: { status: string; details?: Record<string, unknown> }) => {
      const statusNotification: NotificationPayload = {
        type: 'status',
        title: 'System Status Update',
        content: data.status,
        timestamp: new Date(),
        priority: 'low',
        targetRole: 'all',
        data: data.details,
      };

      io.emit('notification', statusNotification);
    });

    // Handle operational alerts
    socket.on('alert:critical', async (data: { title: string; content: string; details?: Record<string, unknown> }) => {
      if (clientContext?.role !== 'admin') {
        socket.emit('error', { message: 'Unauthorized' });
        return;
      }

      const alertNotification: NotificationPayload = {
        type: 'alert',
        title: data.title,
        content: data.content,
        timestamp: new Date(),
        priority: 'critical',
        targetRole: 'admin',
        data: data.details,
      };

      io.to('role:admin').emit('notification', alertNotification);
      await logNotification(alertNotification);
    });

    // Handle member presence
    socket.on('presence:update', (data: { status: 'online' | 'away' | 'offline' }) => {
      socket.broadcast.emit('presence', {
        userId: clientContext?.userId,
        username: clientContext?.username,
        status: data.status,
        timestamp: new Date(),
      });
    });

    // Handle typing indicators
    socket.on('typing:start', (data: { channel: string }) => {
      socket.broadcast.to(data.channel).emit('typing', {
        userId: clientContext?.userId,
        username: clientContext?.username,
        channel: data.channel,
      });
    });

    socket.on('typing:stop', (data: { channel: string }) => {
      socket.broadcast.to(data.channel).emit('typing:stopped', {
        userId: clientContext?.userId,
        channel: data.channel,
      });
    });

    // Handle subscription to specific channels
    socket.on('subscribe', (data: { channel: string }) => {
      socket.join(data.channel);
      socket.emit('subscribed', { channel: data.channel });
    });

    socket.on('unsubscribe', (data: { channel: string }) => {
      socket.leave(data.channel);
      socket.emit('unsubscribed', { channel: data.channel });
    });

    // Disconnect handler
    socket.on('disconnect', () => {
      connectedClients.delete(socket.id);
      console.log(`[WebSocket] Client disconnected: ${socket.id}`);
      
      io.emit('presence', {
        userId: clientContext?.userId,
        status: 'offline',
        timestamp: new Date(),
      });
    });

    // Error handler
    socket.on('error', (error: Error) => {
      console.error(`[WebSocket] Socket error: ${error.message}`);
    });
  });

  return io;
}

async function logNotification(notification: NotificationPayload): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    // Store notification in database for audit trail
    console.log(`[Notification Log] ${notification.type}: ${notification.title}`);
  } catch (error) {
    console.error('[Notification Log] Error logging notification:', error);
  }
}

export function broadcastNotification(
  io: SocketIOServer,
  notification: NotificationPayload
): void {
  if (notification.targetRole === 'all') {
    io.emit('notification', notification);
  } else if (notification.targetRole) {
    io.to(`role:${notification.targetRole}`).emit('notification', notification);
  }
}

export function getConnectedClientsCount(): number {
  return connectedClients.size;
}

export function getConnectedClientsByRole(role: string): number {
  return Array.from(connectedClients.values()).filter(
    (client) => client.role === role
  ).length;
}
