# KBH@NIGHT Automation Scripts

**TEST USE ONLY** - For authorized red team testing within defined scope only.

## Overview

This directory contains three main automation scripts for the KBH@NIGHT framework:

1. **Signal Auto-Poster** – Automatic Signal group messaging
2. **Distributed Host Client** – Silent background website hosting
3. **GitHub Actions Workflows** – Automated host rotation and deployment

## 1. Signal Auto-Poster (`signal-auto-poster.py`)

### Purpose
Automates Signal group messaging with automatic dependency installation and QR code device linking.

### Features
- Automatic Java and signal-cli installation
- QR code generation for device linking
- Batch message posting to Signal groups
- Automatic dependency management
- GUI interface with progress tracking

### Installation & Usage

```bash
# Install Python dependencies
pip install qrcode[pil] pillow requests

# Run the application
python3 signal-auto-poster.py
```

### Step-by-Step Guide

1. **System Setup**
   - Click "1. Setup System"
   - Script checks for Java (install from https://adoptium.net/ if needed)
   - Automatically downloads and extracts signal-cli

2. **Link Device**
   - Click "2. Link Device (QR)"
   - Scan the QR code with Signal app: Settings → Linked Devices → Link New Device
   - Wait for linking to complete

3. **Send Messages**
   - Enter recipient group IDs (comma-separated)
   - Type your message
   - Click "3. SEND MESSAGES"
   - Monitor progress in status box

### Finding Group IDs

After linking your device, run in terminal:

```bash
./signal-cli/bin/signal-cli listGroups
```

This displays all your groups with their Base64-encoded IDs.

### Important Notes

- **Spam Risk**: Signal blocks accounts sending to many groups rapidly. Use delays between messages.
- **TEST USE ONLY**: This tool is for authorized testing only.
- **Rate Limiting**: Implement delays between group messages to avoid detection.

---

## 2. Distributed Host Client (`distributed-host-client.py`)

### Purpose
Silent background script that monitors a central JSON file and automatically hosts the website when assigned.

### Features
- Automatic GitHub token registration
- Silent background operation
- ngrok tunnel integration for public access
- Automatic startup on Windows
- Configuration persistence
- Logging of hosting sessions

### Installation & Usage

```bash
# Install Python dependencies
pip install pyngrok requests

# First run (setup)
python3 distributed-host-client.py

# Subsequent runs (automatic)
python3 distributed-host-client.py
```

### Initial Setup

On first run, you'll be prompted for:

1. **Forum Username** – Your username (must match members.txt)
2. **GitHub Team Token** – Shared team token for repository access
3. **ngrok Auth Token** – From https://dashboard.ngrok.com
4. **JSON URL** – URL to current_host.json (e.g., https://raw.githubusercontent.com/your-org/repo/main/current_host.json)

### How It Works

1. Script monitors the central `current_host.json` file
2. When your name appears in `current_host`, it automatically:
   - Starts a local HTTP server on port 8000
   - Creates an ngrok tunnel for public access
   - Logs the public URL
3. When your name is removed, it shuts down gracefully

### Configuration Storage

Configuration is stored in:
- **Windows**: `%APPDATA%\KBHNight\config.json`
- **Linux/Mac**: `~/.config/KBHNight/config.json`

Permissions are restricted to owner-only (0o600).

### Silent Background Execution (Windows)

To run silently on startup:

1. Create a `.vbs` file in Startup folder:
   ```vbs
   Set objShell = CreateObject("WScript.Shell")
   objShell.Run "python.exe ""C:\path\to\distributed-host-client.py""", 0, False
   ```

2. Or use the automatic startup script creation (runs on first execution)

### Logging

Hosting sessions are logged to:
- **Windows**: `%APPDATA%\KBHNight\hosting_log.txt`
- **Linux/Mac**: `~/.config/KBHNight/hosting_log.txt`

---

## 3. GitHub Actions Workflows

### Host Rotation Workflow (`.github/workflows/rotate-host.yml`)

#### Schedule
- **Days**: Thursday, Friday, Saturday
- **Time**: 00:00 UTC
- **Cron**: `0 0 * * 4,5,6`

#### How It Works

1. Reads `members.txt` file
2. Selects a random member
3. Updates `current_host.json` with the selected member
4. Commits and pushes changes to repository
5. Logs the rotation

#### Configuration

Edit `members.txt` to add/remove team members:

```
member1
member2
member3
member4
member5
```

#### Manual Trigger

Trigger rotation manually:

```bash
gh workflow run rotate-host.yml
```

Or via GitHub UI: Actions → Rotate Distributed Host → Run workflow

---

## 4. Daily Deployment Workflow (`.github/workflows/daily-deploy.yml`)

#### Schedule
- **Days**: Monday-Friday
- **Time**: 02:00 UTC
- **Cron**: `0 2 * * 1-5`

#### Configuration

Modify deployment days using the configuration script:

```bash
node scripts/configure-deployment-days.mjs --days 1-5 --time 02:00
```

---

## Integration Guide

### Step 1: Repository Setup

```bash
# Clone or create repository
git clone <your-repo>
cd <your-repo>

# Add members list
echo "member1" > members.txt
echo "member2" >> members.txt

# Initialize current_host.json
echo '{"current_host": "member1", "updated": "now"}' > current_host.json

# Commit
git add members.txt current_host.json
git commit -m "Initialize distributed hosting"
git push
```

### Step 2: Distribute Client Script

1. Give each team member `distributed-host-client.py`
2. They run it once to setup (enters credentials)
3. Script runs silently in background thereafter

### Step 3: Monitor Hosting

Check who's currently hosting:

```bash
curl https://raw.githubusercontent.com/your-org/repo/main/current_host.json
```

---

## Security Considerations

- **TEST USE ONLY** – All scripts labeled for authorized testing only
- **Token Security** – GitHub tokens stored locally with restricted permissions
- **Scope Limitation** – Ensure all activities remain within authorized scope
- **Audit Logging** – All hosting sessions logged for compliance
- **Configuration Encryption** – Consider encrypting config.json for production use

---

## Troubleshooting

### Signal Auto-Poster

**Java not found:**
```bash
# Install OpenJDK 17+
# Windows: https://adoptium.net/
# Linux: sudo apt install openjdk-17-jre
# macOS: brew install openjdk@17
```

**signal-cli download fails:**
- Check internet connection
- Verify GitHub is accessible
- Try manual download from: https://github.com/AsamK/signal-cli/releases

### Distributed Host Client

**Config not found:**
- Delete config.json and run setup again
- Verify file permissions

**ngrok tunnel fails:**
- Check ngrok auth token validity
- Verify ngrok service is accessible

**JSON URL not responding:**
- Verify GitHub repository is public
- Check URL format and permissions

---

## Compliance & Documentation

All scripts include:
- TEST USE ONLY labeling
- Comprehensive logging
- Audit trail generation
- Scope limitation checks

This ensures full traceability for post-engagement review and compliance reporting.

---

**TEST USE ONLY** - Authorized Testing Framework  
For use only within the defined Rules of Engagement scope.
