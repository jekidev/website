import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Lock, Send, LogOut, AlertTriangle } from 'lucide-react';

/**
 * KBH@NIGHT Landing Page - Professional Edition
 * Design Philosophy: Minimalist Sophistication
 * - Clean, professional HUD aesthetic
 * - Subtle animations and transitions
 * - Video background with elegant overlay
 * - Refined typography and spacing
 */

interface AccessState {
  status: 'initial' | 'denied' | 'granted';
  message: string;
}

export default function Home() {
  const [code, setCode] = useState('');
  const [accessState, setAccessState] = useState<AccessState>({ status: 'initial', message: '' });
  const [showDisclaimer, setShowDisclaimer] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [showForum, setShowForum] = useState(false);
  const [forumMessage, setForumMessage] = useState('');

  const validCodes = ['VOID-2026', 'NIGHT-SOCIETY', 'KBH-COLLECTIVE'];

  useEffect(() => {
    const stored = localStorage.getItem('kbh_authenticated');
    if (stored) {
      setAuthenticated(true);
      setShowDisclaimer(false);
    }
  }, []);

  const handleCodeSubmit = () => {
    const trimmedCode = code.toUpperCase().trim();

    if (validCodes.includes(trimmedCode)) {
      setAccessState({ status: 'granted', message: 'ACCESS GRANTED' });
      setAuthenticated(true);
      localStorage.setItem('kbh_authenticated', 'true');
      setCode('');

      setTimeout(() => {
        setShowForum(true);
      }, 600);
    } else {
      setAccessState({ status: 'denied', message: 'ACCESS DENIED' });
      setCode('');

      setTimeout(() => {
        setAccessState({ status: 'initial', message: '' });
      }, 1500);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCodeSubmit();
    }
  };

  const handleLogout = () => {
    setShowForum(false);
    setAuthenticated(false);
    localStorage.removeItem('kbh_authenticated');
  };

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-black">
      {/* Video Background */}
      <video
        autoPlay
        muted
        loop
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'brightness(0.6) contrast(1.1)' }}
      >
        <source src="/background.mp4" type="video/mp4" />
      </video>

      {/* Overlay Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/70" />

      {/* Disclaimer Modal */}
      <Dialog open={showDisclaimer} onOpenChange={setShowDisclaimer}>
        <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-md shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-light tracking-widest text-white flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              SECURITY NOTICE
            </DialogTitle>
          </DialogHeader>
          <DialogDescription className="space-y-4 text-gray-300 text-sm">
            <p className="leading-relaxed">
              You are accessing a restricted network. Unauthorized access is prohibited and monitored.
            </p>
            <p className="text-xs text-gray-400 font-mono">
              All communications are encrypted and logged. Discretion required.
            </p>
          </DialogDescription>
          <div className="flex gap-3 pt-4">
            <Button
              onClick={() => setShowDisclaimer(false)}
              className="flex-1 bg-white text-black hover:bg-gray-200 font-semibold text-sm h-10"
            >
              PROCEED
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 sm:px-8 py-12">
        {!showForum ? (
          // Landing Page
          <div className="w-full max-w-2xl">
            {/* Logo Section */}
            <div className="text-center mb-16 md:mb-20">
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-light tracking-tight text-white mb-4" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
                KBH@NIGHT
              </h1>
              <div className="h-px w-24 bg-gradient-to-r from-transparent via-white to-transparent mx-auto mb-6" />
              <p className="text-sm md:text-base font-light tracking-widest text-gray-300 uppercase">
                Copenhagen Elite Collective
              </p>
            </div>

            {/* Access Code Input */}
            {!authenticated ? (
              <div className="space-y-6">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="ENTER ACCESS CODE"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-6 py-4 text-center text-lg font-mono tracking-widest text-white placeholder:text-gray-500 focus:outline-none focus:border-white/40 focus:bg-white/10 transition-all duration-300 backdrop-blur-sm"
                    autoComplete="off"
                    spellCheck="false"
                  />
                </div>

                {/* Status Message */}
                {accessState.status === 'denied' && (
                  <div className="text-center text-red-400 font-mono text-xs tracking-widest animate-pulse">
                    {accessState.message}
                  </div>
                )}
                {accessState.status === 'granted' && (
                  <div className="text-center text-emerald-400 font-mono text-xs tracking-widest animate-pulse">
                    {accessState.message}
                  </div>
                )}

                {/* Submit Button */}
                <button
                  onClick={handleCodeSubmit}
                  className="w-full bg-white text-black font-semibold py-4 rounded-lg hover:bg-gray-100 transition-all duration-300 text-sm tracking-widest uppercase hover:shadow-lg hover:shadow-white/20"
                >
                  ENTER
                </button>
              </div>
            ) : null}

            {/* Footer */}
            <div className="text-center mt-16 text-xs text-gray-500 font-mono tracking-widest">
              KBH@NIGHT 2026 · ENCRYPTED · MEMBERS ONLY
            </div>
          </div>
        ) : (
          // Member Forum
          <div className="w-full max-w-3xl">
            {/* Forum Header */}
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-light tracking-tight text-white mb-2" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
                COLLECTIVE FORUM
              </h2>
              <div className="h-px w-16 bg-gradient-to-r from-transparent via-white to-transparent mx-auto" />
            </div>

            {/* Forum Container */}
            <div className="space-y-6">
              {/* Forum Posts */}
              <div className="space-y-4 max-h-96 overflow-y-auto pr-4 custom-scrollbar">
                {[
                  { author: 'ADMIN', time: '23:47', message: 'Welcome to the collective. Operational security is mandatory.' },
                  { author: 'MEMBER_7', time: '22:15', message: 'Next gathering Friday. Coordinates shared via encrypted channel.' },
                  { author: 'MEMBER_12', time: '20:33', message: 'New members onboarded. Remember: discretion is non-negotiable.' },
                  { author: 'MEMBER_3', time: '18:52', message: 'Updated security protocols in effect. Review immediately.' },
                ].map((post, idx) => (
                  <div key={idx} className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-mono text-white text-sm font-semibold">{post.author}</span>
                      <span className="font-mono text-gray-500 text-xs">{post.time}</span>
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed">{post.message}</p>
                  </div>
                ))}
              </div>

              {/* Message Composer */}
              <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
                <label className="block text-white font-mono text-xs font-semibold mb-4 tracking-widest">
                  COMPOSE MESSAGE
                </label>
                <textarea
                  placeholder="Type your message..."
                  value={forumMessage}
                  onChange={(e) => setForumMessage(e.target.value)}
                  className="w-full bg-black/30 border border-white/10 rounded p-4 text-gray-300 font-mono text-sm focus:outline-none focus:border-white/30 focus:bg-black/50 resize-none transition-all duration-300 placeholder:text-gray-600"
                  rows={3}
                />
                <div className="flex gap-3 mt-4">
                  <button className="flex-1 bg-white text-black font-semibold py-3 rounded hover:bg-gray-100 transition-all duration-300 text-sm tracking-widest uppercase flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-white/20">
                    <Send className="w-4 h-4" />
                    SEND
                  </button>
                  <button
                    onClick={handleLogout}
                    className="px-6 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold py-3 rounded transition-all duration-300 text-sm tracking-widest uppercase flex items-center gap-2 hover:shadow-lg hover:shadow-red-500/10"
                  >
                    <LogOut className="w-4 h-4" />
                    EXIT
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.2);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
}
