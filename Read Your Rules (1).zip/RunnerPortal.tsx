import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Download, MessageSquare, User, LogOut, Send, Smartphone } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface RunnerState {
  authenticated: boolean;
  username: string;
  profileImage: string;
  bio: string;
  appVersion: string;
  lastActive: string;
}

export default function RunnerPortal() {
  const [runner, setRunner] = useState<RunnerState>({
    authenticated: false,
    username: '',
    profileImage: '',
    bio: '',
    appVersion: '1.0.0',
    lastActive: new Date().toISOString(),
  });

  const [code, setCode] = useState('');
  const [showLogin, setShowLogin] = useState(!runner.authenticated);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [messageSubject, setMessageSubject] = useState('');
  const [showMessageForm, setShowMessageForm] = useState(false);

  const validRunnerCode = 'family2026!';

  const handleRunnerLogin = () => {
    if (code.toUpperCase().trim() === validRunnerCode) {
      setRunner({
        ...runner,
        authenticated: true,
        username: `Runner_${Math.random().toString(36).substr(2, 9)}`,
        lastActive: new Date().toISOString(),
      });
      setShowLogin(false);
      setCode('');
      setFailedAttempts(0);
    } else {
      setFailedAttempts(failedAttempts + 1);
      setCode('');
    }
  };

  const handleLogout = () => {
    setRunner({
      authenticated: false,
      username: '',
      profileImage: '',
      bio: '',
      appVersion: '1.0.0',
      lastActive: new Date().toISOString(),
    });
    setShowLogin(true);
    setMessages([]);
  };

  const handleSendMessage = () => {
    if (messageSubject.trim() && newMessage.trim()) {
      setMessages([
        ...messages,
        {
          id: messages.length + 1,
          subject: messageSubject,
          message: newMessage,
          status: 'unread',
          createdAt: new Date().toISOString(),
        },
      ]);
      setMessageSubject('');
      setNewMessage('');
      setShowMessageForm(false);
    }
  };

  const downloadApp = (platform: 'ios' | 'android') => {
    const downloadUrl = platform === 'ios' 
      ? 'https://apps.apple.com/app/kbh-night-runner/id0000000000'
      : 'https://play.google.com/store/apps/details?id=com.kbhnight.runner';
    
    window.open(downloadUrl, '_blank');
  };

  if (!runner.authenticated) {
    return (
      <div className="relative w-full min-h-screen overflow-hidden bg-black">
        <video
          autoPlay
          muted
          loop
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'brightness(0.4) contrast(1.2)' }}
        >
          <source src="/grok-video-4edfd5f3-4559-46c4-867a-516d1af9088a.mp4" type="video/mp4" />
        </video>

        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/70 to-black/80" />

        <div className="relative z-10 min-h-screen flex items-center justify-center px-4">
          <div className="w-full max-w-md">
            <div className="text-center mb-12">
              <h1 className="text-6xl font-light tracking-tight text-white mb-4" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
                RUNNER
              </h1>
              <div className="h-px w-24 bg-gradient-to-r from-transparent via-cyan-400 to-transparent mx-auto mb-4" />
              <p className="text-sm tracking-widest text-cyan-400 uppercase">Operational Portal</p>
            </div>

            <div className="space-y-6">
              <div className="relative">
                <input
                  type="password"
                  placeholder="ENTER ACCESS CODE"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleRunnerLogin()}
                  className="w-full bg-white/5 border border-white/20 rounded-lg px-6 py-4 text-center text-lg font-mono tracking-widest text-white placeholder:text-gray-500 focus:outline-none focus:border-cyan-400/40 focus:bg-white/10 transition-all duration-300 backdrop-blur-sm"
                  autoComplete="off"
                  spellCheck="false"
                />
              </div>

              {failedAttempts > 0 && (
                <div className="text-center text-red-400 font-mono text-xs tracking-widest animate-pulse">
                  INVALID CODE - {failedAttempts} ATTEMPT{failedAttempts > 1 ? 'S' : ''}
                </div>
              )}

              <button
                onClick={handleRunnerLogin}
                className="w-full bg-cyan-500 text-black font-semibold py-4 rounded-lg hover:bg-cyan-400 transition-all duration-300 text-sm tracking-widest uppercase hover:shadow-lg hover:shadow-cyan-500/50"
              >
                ACCESS PORTAL
              </button>

              <div className="text-center text-xs text-gray-500 font-mono tracking-widest">
                RUNNER OPERATIONS · ENCRYPTED · AUTHORIZED ONLY
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-black">
      {/* Header */}
      <div className="border-b border-cyan-500/20 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-light tracking-widest text-white" style={{ fontFamily: 'Orbitron' }}>
              RUNNER PORTAL
            </h1>
            <p className="text-xs text-cyan-400 font-mono tracking-widest">{runner.username}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/40 border border-red-500/50 rounded-lg text-red-400 text-sm font-mono transition-all"
          >
            <LogOut className="w-4 h-4" />
            EXIT
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/50 border border-cyan-500/20 rounded-lg p-1">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="forum" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              Forum
            </TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              Messages
            </TabsTrigger>
            <TabsTrigger value="apps" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              Apps
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-cyan-400 font-mono">STATUS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-light text-white">ACTIVE</div>
                  <p className="text-xs text-gray-400 mt-2">Last active: {new Date(runner.lastActive).toLocaleTimeString()}</p>
                </CardContent>
              </Card>

              <Card className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-cyan-400 font-mono">APP VERSION</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-light text-white">v{runner.appVersion}</div>
                  <p className="text-xs text-gray-400 mt-2">Latest available</p>
                </CardContent>
              </Card>

              <Card className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-cyan-400 font-mono">UNREAD</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-light text-white">{messages.filter(m => m.status === 'unread').length}</div>
                  <p className="text-xs text-gray-400 mt-2">Admin messages</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/50 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-cyan-400 font-mono">PROFILE</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                    <User className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-mono">{runner.username}</p>
                    <p className="text-xs text-gray-400">Runner Operative</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Forum Tab */}
          <TabsContent value="forum" className="space-y-6 mt-6">
            <Card className="bg-black/50 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-cyan-400 font-mono">RUNNER FORUM</CardTitle>
                <CardDescription className="text-gray-400">Exclusive runner operations channel</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {[
                    { author: 'ADMIN', time: '23:47', message: 'Welcome runners. Operational briefing at 22:00.' },
                    { author: 'RUNNER_ALPHA', time: '22:15', message: 'Ready for deployment. Standing by for orders.' },
                    { author: 'RUNNER_BETA', time: '20:33', message: 'Equipment check complete. All systems nominal.' },
                  ].map((post, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/10 rounded-lg p-4 hover:bg-white/10 transition-all">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-mono text-cyan-400 text-sm">{post.author}</span>
                        <span className="font-mono text-gray-500 text-xs">{post.time}</span>
                      </div>
                      <p className="text-gray-300 text-sm">{post.message}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6 mt-6">
            <div className="flex justify-end mb-4">
              <Button
                onClick={() => setShowMessageForm(!showMessageForm)}
                className="bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500/50 text-cyan-400 font-mono text-xs"
              >
                <Send className="w-4 h-4 mr-2" />
                NEW MESSAGE
              </Button>
            </div>

            {showMessageForm && (
              <Card className="bg-black/50 border-cyan-500/20">
                <CardHeader>
                  <CardTitle className="text-cyan-400 font-mono">COMPOSE MESSAGE</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <input
                    type="text"
                    placeholder="Subject"
                    value={messageSubject}
                    onChange={(e) => setMessageSubject(e.target.value)}
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder:text-gray-500 focus:outline-none focus:border-cyan-400/40 focus:bg-white/10 font-mono text-sm"
                  />
                  <textarea
                    placeholder="Your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder:text-gray-500 focus:outline-none focus:border-cyan-400/40 focus:bg-white/10 font-mono text-sm resize-none h-24"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleSendMessage}
                      className="flex-1 bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500/50 text-cyan-400 font-mono text-xs"
                    >
                      SEND
                    </Button>
                    <Button
                      onClick={() => setShowMessageForm(false)}
                      className="flex-1 bg-white/5 hover:bg-white/10 border border-white/20 text-gray-400 font-mono text-xs"
                    >
                      CANCEL
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {messages.length === 0 ? (
                <Card className="bg-black/50 border-cyan-500/20">
                  <CardContent className="pt-6 text-center">
                    <MessageSquare className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                    <p className="text-gray-400 text-sm">No messages yet</p>
                  </CardContent>
                </Card>
              ) : (
                messages.map((msg) => (
                  <Card key={msg.id} className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-cyan-400 font-mono text-sm">{msg.subject}</CardTitle>
                        <span className="text-xs text-gray-500 font-mono">{new Date(msg.createdAt).toLocaleString()}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300 text-sm">{msg.message}</p>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Apps Tab */}
          <TabsContent value="apps" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all cursor-pointer" onClick={() => downloadApp('ios')}>
                <CardHeader>
                  <CardTitle className="text-cyan-400 font-mono flex items-center gap-2">
                    <Smartphone className="w-5 h-5" />
                    iOS App
                  </CardTitle>
                  <CardDescription className="text-gray-400">iPhone & iPad</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-xs text-gray-400 mb-2">VERSION</p>
                    <p className="text-white font-mono">v{runner.appVersion}</p>
                  </div>
                  <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500/50 text-cyan-400 font-mono text-xs">
                    <Download className="w-4 h-4 mr-2" />
                    DOWNLOAD
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-black/50 border-cyan-500/20 hover:border-cyan-500/40 transition-all cursor-pointer" onClick={() => downloadApp('android')}>
                <CardHeader>
                  <CardTitle className="text-cyan-400 font-mono flex items-center gap-2">
                    <Smartphone className="w-5 h-5" />
                    Android App
                  </CardTitle>
                  <CardDescription className="text-gray-400">Android Devices</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-xs text-gray-400 mb-2">VERSION</p>
                    <p className="text-white font-mono">v{runner.appVersion}</p>
                  </div>
                  <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-500/50 text-cyan-400 font-mono text-xs">
                    <Download className="w-4 h-4 mr-2" />
                    DOWNLOAD
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/50 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-cyan-400 font-mono">INSTALLATION GUIDE</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm text-gray-300">
                <div>
                  <p className="font-mono text-cyan-400 mb-2">iOS:</p>
                  <ol className="list-decimal list-inside space-y-1 text-xs">
                    <li>Open App Store</li>
                    <li>Search for "KBH@NIGHT Runner"</li>
                    <li>Tap Install</li>
                    <li>Launch and enter your runner code</li>
                  </ol>
                </div>
                <div>
                  <p className="font-mono text-cyan-400 mb-2">Android:</p>
                  <ol className="list-decimal list-inside space-y-1 text-xs">
                    <li>Open Google Play Store</li>
                    <li>Search for "KBH@NIGHT Runner"</li>
                    <li>Tap Install</li>
                    <li>Launch and enter your runner code</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
