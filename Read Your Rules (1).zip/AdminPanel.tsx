import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Settings, Users, Radio, BarChart3, LogOut, Plus, Trash2, Edit } from 'lucide-react';

/**
 * KBH@NIGHT Admin Control Panel
 * Design Philosophy: Command & Control Interface
 * - Operational hierarchy management
 * - Member role assignment
 * - Communication channel configuration
 * - Performance metrics dashboard
 */

interface HierarchyMember {
  id: string;
  name: string;
  role: 'boss' | 'underboss' | 'capo' | 'soldier';
  status: 'active' | 'inactive' | 'compromised';
  joinDate: string;
}

interface CommunicationChannel {
  id: string;
  name: string;
  type: 'signal' | 'telegram' | 'encrypted_mesh';
  members: number;
  status: 'active' | 'dormant' | 'compromised';
}

interface OperationalMetrics {
  totalMembers: number;
  activeCells: number;
  messagesTodayCount: number;
  systemUptime: string;
  lastIncident: string;
}

export default function AdminPanel() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showPasswordDialog, setShowPasswordDialog] = useState(true);
  const [hierarchyMembers, setHierarchyMembers] = useState<HierarchyMember[]>([
    { id: '1', name: 'ALPHA_LEAD', role: 'boss', status: 'active', joinDate: '2025-09-15' },
    { id: '2', name: 'BETA_OPS', role: 'underboss', status: 'active', joinDate: '2025-10-01' },
    { id: '3', name: 'GAMMA_CELL', role: 'capo', status: 'active', joinDate: '2025-10-15' },
  ]);

  const [channels, setChannels] = useState<CommunicationChannel[]>([
    { id: '1', name: 'SECURE_BROADCAST', type: 'signal', members: 12, status: 'active' },
    { id: '2', name: 'ENCRYPTED_MESH', type: 'encrypted_mesh', members: 8, status: 'active' },
    { id: '3', name: 'TELEGRAM_RELAY', type: 'telegram', members: 15, status: 'dormant' },
  ]);

  const [metrics, setMetrics] = useState<OperationalMetrics>({
    totalMembers: 35,
    activeCells: 7,
    messagesTodayCount: 247,
    systemUptime: '99.8%',
    lastIncident: '2 days ago',
  });

  const [editingMember, setEditingMember] = useState<HierarchyMember | null>(null);
  const [showMemberDialog, setShowMemberDialog] = useState(false);

  const handlePasswordSubmit = () => {
    // TEST USE ONLY - In production, use proper authentication
    if (adminPassword === 'VOID-ADMIN-2026') {
      setIsAdmin(true);
      setShowPasswordDialog(false);
      setAdminPassword('');
    } else {
      alert('INVALID CREDENTIALS');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setShowPasswordDialog(true);
    setAdminPassword('');
  };

  const handleDeleteMember = (id: string) => {
    setHierarchyMembers(hierarchyMembers.filter(m => m.id !== id));
  };

  const handleEditMember = (member: HierarchyMember) => {
    setEditingMember(member);
    setShowMemberDialog(true);
  };

  const handleSaveMember = () => {
    if (editingMember) {
      setHierarchyMembers(
        hierarchyMembers.map(m => m.id === editingMember.id ? editingMember : m)
      );
      setShowMemberDialog(false);
      setEditingMember(null);
    }
  };

  if (!isAdmin) {
    return (
      <div className="relative w-full min-h-screen overflow-hidden bg-black">
        <video
          autoPlay
          muted
          loop
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'brightness(0.6) contrast(1.1)' }}
        >
          <source src="/grok-video-4edfd5f3-4559-46c4-867a-516d1af9088a.mp4" type="video/mp4" />
        </video>

        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/70" />

        <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
          <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-md shadow-2xl">
            <DialogHeader>
              <DialogTitle className="text-lg font-light tracking-widest text-white flex items-center gap-3">
                <Settings className="w-4 h-4 text-cyan-400" />
                ADMIN AUTHENTICATION
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <input
                type="password"
                placeholder="ENTER ADMIN CODE"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
                className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 text-center text-sm font-mono tracking-widest text-white placeholder:text-gray-500 focus:outline-none focus:border-white/40 focus:bg-white/10 transition-all duration-300"
              />
              <Button
                onClick={handlePasswordSubmit}
                className="w-full bg-white text-black hover:bg-gray-200 font-semibold text-sm h-10"
              >
                AUTHENTICATE
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-black">
      <video
        autoPlay
        muted
        loop
        className="absolute inset-0 w-full h-full object-cover"
        style={{ filter: 'brightness(0.3) contrast(1.2)' }}
      >
        <source src="/grok-video-65aa1047-1315-4729-b3d4-efb51ddbc143.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/80" />

      <div className="relative z-10 min-h-screen px-4 sm:px-8 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-12">
            <div>
              <h1 className="text-4xl sm:text-5xl font-light tracking-tight text-white mb-2" style={{ fontFamily: 'Orbitron, monospace', fontWeight: 900 }}>
                COMMAND CENTER
              </h1>
              <div className="h-px w-32 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
            </div>
            <Button
              onClick={handleLogout}
              className="bg-red-600/20 hover:bg-red-600/40 border border-red-500/50 text-red-400 font-semibold px-6 py-3 rounded transition-all duration-300 flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              EXIT
            </Button>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">TOTAL MEMBERS</div>
              <div className="text-2xl font-bold text-cyan-400">{metrics.totalMembers}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">ACTIVE CELLS</div>
              <div className="text-2xl font-bold text-cyan-400">{metrics.activeCells}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">MESSAGES TODAY</div>
              <div className="text-2xl font-bold text-cyan-400">{metrics.messagesTodayCount}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">UPTIME</div>
              <div className="text-2xl font-bold text-emerald-400">{metrics.systemUptime}</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-4 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
              <div className="text-xs font-mono text-gray-400 mb-2">LAST INCIDENT</div>
              <div className="text-2xl font-bold text-amber-400">{metrics.lastIncident}</div>
            </div>
          </div>

          {/* Hierarchy Management */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Members */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-light tracking-widest text-white flex items-center gap-3" style={{ fontFamily: 'Orbitron, monospace' }}>
                  <Users className="w-5 h-5 text-cyan-400" />
                  HIERARCHY
                </h2>
                <Button
                  onClick={() => setShowMemberDialog(true)}
                  className="bg-cyan-600/20 hover:bg-cyan-600/40 border border-cyan-500/50 text-cyan-400 text-xs px-3 py-1 rounded flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  ADD
                </Button>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {hierarchyMembers.map(member => (
                  <div key={member.id} className="bg-black/30 border border-white/10 rounded p-3 flex justify-between items-center hover:border-white/20 transition-all">
                    <div className="flex-1">
                      <div className="font-mono text-sm text-white font-semibold">{member.name}</div>
                      <div className="text-xs text-gray-400 mt-1">
                        <span className={`px-2 py-1 rounded text-xs font-mono ${
                          member.role === 'boss' ? 'bg-red-500/20 text-red-400' :
                          member.role === 'underboss' ? 'bg-orange-500/20 text-orange-400' :
                          member.role === 'capo' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {member.role.toUpperCase()}
                        </span>
                        <span className={`ml-2 px-2 py-1 rounded text-xs font-mono ${
                          member.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' :
                          member.status === 'inactive' ? 'bg-gray-500/20 text-gray-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {member.status.toUpperCase()}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditMember(member)}
                        className="p-2 hover:bg-white/10 rounded transition-all"
                      >
                        <Edit className="w-4 h-4 text-cyan-400" />
                      </button>
                      <button
                        onClick={() => handleDeleteMember(member.id)}
                        className="p-2 hover:bg-white/10 rounded transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Communication Channels */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
              <h2 className="text-xl font-light tracking-widest text-white flex items-center gap-3 mb-6" style={{ fontFamily: 'Orbitron, monospace' }}>
                <Radio className="w-5 h-5 text-cyan-400" />
                CHANNELS
              </h2>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {channels.map(channel => (
                  <div key={channel.id} className="bg-black/30 border border-white/10 rounded p-3 hover:border-white/20 transition-all">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="font-mono text-sm text-white font-semibold">{channel.name}</div>
                        <div className="text-xs text-gray-400 mt-1 flex gap-2">
                          <span className="px-2 py-1 rounded bg-blue-500/20 text-blue-400">{channel.type.toUpperCase()}</span>
                          <span className={`px-2 py-1 rounded ${
                            channel.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' :
                            channel.status === 'dormant' ? 'bg-gray-500/20 text-gray-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {channel.status.toUpperCase()}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-cyan-400 font-mono">{channel.members}</div>
                        <div className="text-xs text-gray-400">MEMBERS</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="mt-8 bg-white/5 border border-white/10 rounded-lg p-6 backdrop-blur-sm">
            <h2 className="text-xl font-light tracking-widest text-white flex items-center gap-3 mb-6" style={{ fontFamily: 'Orbitron, monospace' }}>
              <BarChart3 className="w-5 h-5 text-cyan-400" />
              OPERATIONAL METRICS
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-black/30 border border-white/10 rounded p-4">
                <div className="text-xs font-mono text-gray-400 mb-3">CELL ISOLATION EFFICACY</div>
                <div className="w-full bg-black/50 rounded h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-cyan-500 to-cyan-400 h-full" style={{ width: '94%' }}></div>
                </div>
                <div className="text-sm text-cyan-400 font-mono mt-2">94%</div>
              </div>
              <div className="bg-black/30 border border-white/10 rounded p-4">
                <div className="text-xs font-mono text-gray-400 mb-3">MTBF (Days)</div>
                <div className="w-full bg-black/50 rounded h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-full" style={{ width: '87%' }}></div>
                </div>
                <div className="text-sm text-emerald-400 font-mono mt-2">87 Days</div>
              </div>
              <div className="bg-black/30 border border-white/10 rounded p-4">
                <div className="text-xs font-mono text-gray-400 mb-3">C2 RECOVERY LATENCY</div>
                <div className="w-full bg-black/50 rounded h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-amber-500 to-amber-400 h-full" style={{ width: '78%' }}></div>
                </div>
                <div className="text-sm text-amber-400 font-mono mt-2">2.3 Minutes</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Member Edit Dialog */}
      <Dialog open={showMemberDialog} onOpenChange={setShowMemberDialog}>
        <DialogContent className="border border-white/10 bg-black/90 backdrop-blur-2xl max-w-md shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-light tracking-widest text-white">
              {editingMember ? 'EDIT MEMBER' : 'ADD MEMBER'}
            </DialogTitle>
          </DialogHeader>
          {editingMember && (
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Member Name"
                value={editingMember.name}
                onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                className="w-full bg-white/5 border border-white/20 rounded px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:border-white/40"
              />
              <select
                value={editingMember.role}
                onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value as any })}
                className="w-full bg-white/5 border border-white/20 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-white/40"
              >
                <option value="soldier">SOLDIER</option>
                <option value="capo">CAPO</option>
                <option value="underboss">UNDERBOSS</option>
                <option value="boss">BOSS</option>
              </select>
              <select
                value={editingMember.status}
                onChange={(e) => setEditingMember({ ...editingMember, status: e.target.value as any })}
                className="w-full bg-white/5 border border-white/20 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-white/40"
              >
                <option value="active">ACTIVE</option>
                <option value="inactive">INACTIVE</option>
                <option value="compromised">COMPROMISED</option>
              </select>
              <Button
                onClick={handleSaveMember}
                className="w-full bg-white text-black hover:bg-gray-200 font-semibold text-sm h-10"
              >
                SAVE
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(34, 211, 238, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(34, 211, 238, 0.5);
        }
      `}</style>
    </div>
  );
}
